import { Fragment, Node, NodeRange, NodeType, Slice } from "prosemirror-model";
import { Transaction } from "prosemirror-state";
import { canJoin, liftTarget, ReplaceAroundStep } from "prosemirror-transform";

import { BlockNoteEditor } from "../../../../editor/BlockNoteEditor.js";
import { CHILD_CONTAINER_GROUP } from "../../../../schema/blocks/children.js";
import { nodeToBlock } from "../../../nodeConversions/nodeToBlock.js";

/**
 * Whether `node` is the sibling list that nesting and unnesting operate on: a
 * node that holds child blocks, and can hold the kind of node being moved.
 *
 * `blockRange` stops at the *deepest* ancestor matching this, so the second
 * condition is load-bearing. A `columnList` holds child blocks, but only
 * `column`s — matching it would resolve the range at the columns themselves,
 * where `sinkItem`'s `nodeBefore` is a `column` rather than a `blockContainer`
 * and `liftItem`'s parent is a `blockGroup` rather than a `blockContainer`, so
 * both bail. Skipping it lets the walk continue out to the `blockGroup` the
 * list sits in, and Tab across two columns indents the list as a unit.
 */
function holdsItems(node: Node, itemType: NodeType) {
  return (
    node.childCount > 0 &&
    node.type.isInGroup(CHILD_CONTAINER_GROUP) &&
    node.type.contentMatch.matchType(itemType) !== null
  );
}

/**
 * Modified version of prosemirror-schema-list's sinkItem.
 * https://github.com/ProseMirror/prosemirror-schema-list/blob/master/src/schema-list.ts
 *
 * Changes from the original:
 * 1. Range predicate checks node.type instead of firstChild.type
 * 2. nestedBefore checks groupType instead of parent.type
 * 3. Slice creates groupType instead of parent.type
 * 4. Operates on Transaction directly instead of state+dispatch
 * 5. Opens the slice into the previous sibling's child group, not into the
 *    group's last child. The original cut one level deeper to keep `insert`
 *    at 1; that failed when the last child was a layout block node (a column
 *    list), which a `blockContainer` can't be joined onto.
 */
function sinkItem(tr: Transaction, itemType: NodeType, groupType: NodeType) {
  const { $from, $to } = tr.selection;
  const range = $from.blockRange($to, (node) => holdsItems(node, itemType)); // change 1
  if (!range) {
    return false;
  }
  const startIndex = range.startIndex;
  if (startIndex === 0) {
    return false;
  }
  const parent = range.parent;
  const nodeBefore = parent.child(startIndex - 1);
  if (nodeBefore.type !== itemType) {
    return false;
  }
  const nestedBefore =
    nodeBefore.lastChild && nodeBefore.lastChild.type === groupType; // change 2
  // The slice opens into the previous sibling and, when it already has a child
  // group, into that group, so the block becomes its last child. (change 5)
  const depth = nestedBefore ? 2 : 1;
  const slice = new Slice(
    Fragment.from(itemType.create(null, Fragment.from(groupType.create()))), // change 3
    depth,
    0,
  );

  const before = range.start;
  const after = range.end;

  // Nothing above can make the schema refuse this step: `parent` holds
  // regular blocks, so it may lose one (a layout block of any blocks has no
  // `min` above 1), and the slice only joins the previous sibling and its
  // group. A refusal here would be a bug, so it throws.
  tr.step(
    new ReplaceAroundStep(
      before - depth,
      after,
      before,
      after,
      slice,
      // `Slice.insertAt` adds the slice's open depth, so this lands at content
      // position 2: inside the group.
      2 - depth,
      true,
    ),
  ).scrollIntoView();

  return true;
}

function nestCommand(editor: BlockNoteEditor<any, any, any>) {
  return (tr: Transaction) =>
    sinkItem(
      tr,
      editor.pmSchema.nodes["blockContainer"],
      editor.pmSchema.nodes["blockGroup"],
    );
}

export function nestBlock(editor: BlockNoteEditor<any, any, any>) {
  return editor.transact(nestCommand(editor));
}

/**
 * Modified version of prosemirror-schema-list's liftToOuterList.
 * https://github.com/ProseMirror/prosemirror-schema-list/blob/master/src/schema-list.ts
 *
 * Changes from the original:
 * 1. Operates on Transaction directly instead of state+dispatch (TipTap compat)
 * 2. When the lifted block already has children (a groupType child), uses deeper
 *    openStart/offset so siblings merge into the existing group instead of
 *    creating a second one (which would violate blockContainer's schema)
 * 3. Uses groupType.create() instead of range.parent.copy() (same as sinkItem)
 */
function liftToOuterList(
  tr: Transaction,
  itemType: NodeType,
  groupType: NodeType, // change 3
  range: NodeRange,
) {
  const end = range.end;
  const endOfList = range.$to.end(range.depth);

  if (end < endOfList) {
    // There are siblings after the lifted items, which must become
    // children of the last item
    const blockBeingLifted = range.parent.child(range.endIndex - 1);
    const nestedAfter =
      blockBeingLifted.lastChild &&
      blockBeingLifted.lastChild.type === groupType; // change 2

    tr.step(
      new ReplaceAroundStep(
        end - (nestedAfter ? 2 : 1), // change 2: go deeper when merging into existing children
        endOfList,
        end,
        endOfList,
        new Slice(
          Fragment.from(
            itemType.create(null, groupType.create()), // change 3
          ),
          nestedAfter ? 2 : 1, // change 2: open deeper when merging into existing children
          0,
        ),
        nestedAfter ? 0 : 1, // change 2: Slice.insertAt offsets by openStart, so 0+2=2 lands inside existing bg
        true,
      ),
    );
    range = new NodeRange(
      tr.doc.resolve(range.$from.pos),
      tr.doc.resolve(endOfList),
      range.depth,
    );
  }

  const target = liftTarget(range);
  if (target == null) {
    return false;
  }

  tr.lift(range, target);

  const $after = tr.doc.resolve(tr.mapping.map(end, -1) - 1);
  if (
    canJoin(tr.doc, $after.pos) &&
    $after.nodeBefore!.type === $after.nodeAfter!.type
  ) {
    tr.join($after.pos);
  }

  tr.scrollIntoView();
  return true;
}

/**
 * Modified version of prosemirror-schema-list's liftListItem.
 * https://github.com/ProseMirror/prosemirror-schema-list/blob/master/src/schema-list.ts
 *
 * Changes from the original:
 * 1. Range predicate checks node.type instead of firstChild.type (same as sinkItem)
 * 2. Passes groupType to liftToOuterList
 * 3. Operates on Transaction directly instead of state+dispatch
 * 4. Skips liftOutOfList (root-level blocks can't be unnested in BlockNote)
 */
export function liftItem(
  tr: Transaction,
  itemType: NodeType,
  groupType: NodeType, // change 2
  // Whether a block may be outdented out of `parent` (its
  // `keyboard.childrenCanOutdent` setting).
  canOutdentFrom: (parent: Node) => boolean,
) {
  const { $from, $to } = tr.selection;
  const range = $from.blockRange($to, (node) => holdsItems(node, itemType)); // change 1
  if (!range) {
    return false;
  }

  const parent = $from.node(range.depth - 1);
  // A block whose children can't be outdented keeps them: unnesting stops at
  // its edge rather than lifting the block out of it.
  if (parent.type === itemType && !canOutdentFrom(parent)) {
    return false;
  }

  if (parent.type === itemType) {
    // Inside a parent node
    return liftToOuterList(tr, itemType, groupType, range); // change 2
  }

  // This is the "liftOutOfList" path — lifting out of a list entirely.
  // Not applicable to BlockNote (root-level blocks can't be unnested). // change 4
  return false;
}

function unnestCommand(editor: BlockNoteEditor<any, any, any>) {
  return (tr: Transaction) =>
    liftItem(
      tr,
      editor.pmSchema.nodes["blockContainer"],
      editor.pmSchema.nodes["blockGroup"],
      (parent) => {
        const block = nodeToBlock(parent, tr.doc);
        return editor.schema.blockSpecs[block.type].implementation.keyboard(
          block,
        ).childrenCanOutdent;
      },
    );
}

export function unnestBlock(editor: BlockNoteEditor<any, any, any>) {
  return editor.transact(unnestCommand(editor));
}

// `canExec` hands the command a transaction it never dispatches, so "can I
// nest?" is answered by nesting and throwing the result away. A second
// statement of the preconditions would drift from the command it describes —
// and did: it read a previous sibling's mere existence, so a layout block
// before the cursor enabled the button while `nestBlock` did nothing.
export function canNestBlock(editor: BlockNoteEditor<any, any, any>) {
  return editor.canExec((state) => nestCommand(editor)(state.tr));
}

export function canUnnestBlock(editor: BlockNoteEditor<any, any, any>) {
  return editor.canExec((state) => unnestCommand(editor)(state.tr));
}
