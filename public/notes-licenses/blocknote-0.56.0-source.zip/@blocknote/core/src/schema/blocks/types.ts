import type { FrameView } from "./frame.js";
/** Define the main block types **/
// import { Extension, Node } from "@tiptap/core";
import type { Node, NodeViewRendererProps } from "@tiptap/core";
import type { Fragment, Node as PMNode, Schema } from "prosemirror-model";
import type { ViewMutationRecord } from "prosemirror-view";
import type { BlockNoteEditor } from "../../editor/BlockNoteEditor.js";
import type {
  Extension,
  ExtensionFactoryInstance,
} from "../../editor/BlockNoteExtension.js";
import type {
  InlineContent,
  InlineContentSchema,
  PartialInlineContent,
  StyledText,
} from "../inlineContent/types.js";
import type { PropSchema, Props } from "../propTypes.js";
import type { BlockKeyboard, BlockKeyboardOption } from "./keyboard.js";
import type { StyleSchema } from "../styles/types.js";

export type BlockNoteDOMElement =
  | "editor"
  | "block"
  | "blockGroup"
  | "blockContent"
  | "inlineContent";

export type BlockNoteDOMAttributes = Partial<{
  [DOMElement in BlockNoteDOMElement]: Record<string, string>;
}>;

export interface BlockConfigMeta<
  TName extends string = string,
  TProps extends PropSchema = PropSchema,
> {
  /**
   * Defines which keyboard shortcut should be used to insert a hard break into the block's inline content.
   * @default "shift+enter"
   * @deprecated Use `experimental_keyboard.enter` and
   * `experimental_keyboard.shiftEnter` instead: `"enter"` is
   * `experimental_keyboard: { enter: "line-break" }`, and `"none"` is
   * `experimental_keyboard: { shiftEnter: "same-as-enter" }`.
   */
  hardBreakShortcut?: "shift+enter" | "enter" | "none";

  /**
   * Whether the block is selectable
   */
  selectable?: boolean;

  /**
   * The accept mime types for the file block
   */
  fileBlockAccept?: string[];

  /**
   * Whether the block is a {@link https://prosemirror.net/docs/ref/#model.NodeSpec.code} block
   */
  code?: boolean;

  /**
   * Whether the block is a {@link https://prosemirror.net/docs/ref/#model.NodeSpec.defining} block
   */
  defining?: boolean;

  /**
   * Whether the block is a {@link https://prosemirror.net/docs/ref/#model.NodeSpec.isolating} block
   */
  isolating?: boolean;

  /**
   * Whether this block type gets a side menu drag handle (and can be dragged
   * by it). Applies to any block type, layout block or not: e.g. a
   * "locked" block can opt out of dragging entirely. A block that opts out is
   * skipped when looking for a drag handle, so the handle falls through to the
   * nearest draggable ancestor.
   * @default `true`, or `false` for a layout block placeable `"namedOnly"`, which
   * can only live in its parent
   */
  draggable?: boolean;

  /**
   * Whether a block dragged onto this block's content or frame chrome becomes
   * its first child (as in Notion's toggles), instead of going before or after
   * it. A block dragged onto its children still goes between them.
   * @default false
   */
  dropsIntoChildren?(block: { type: TName; props: Props<TProps> }): boolean;

  /**
   * Enables syntax highlighting of the contents of the block with the result of this callback
   */
  highlight?(block: { type: TName; props: Props<TProps> }): string | undefined;

  /**
   * Marks the block as rendering a preview with an editable source popup, driven
   * by the editor-wide `SourceBlockWithPreviewExtension`. When `true`, the
   * block's source is hidden behind its preview and edited via the popup.
   */
  hasPreview?: boolean;
}

/**
 * A block's `meta` with every default applied: what a block spec in a schema
 * holds, so readers never see a missing setting (see `resolveBlockMeta`).
 */
export type ResolvedBlockConfigMeta<
  TName extends string = string,
  TProps extends PropSchema = PropSchema,
> = BlockConfigMeta<TName, TProps> &
  Required<
    Pick<
      BlockConfigMeta<TName, TProps>,
      "selectable" | "code" | "defining" | "isolating" | "draggable"
    >
  >;

/**
 * The type name of a layout block, as used in {@link ChildrenConfig.allow}.
 */
export type AllowedChildType = string;

/**
 * What may appear as a child of a layout block.
 *
 * - `"blocks"`: any regular block, or any layout block placeable anywhere.
 *   This cannot be narrowed to specific regular block types: every regular
 *   block is the *same* ProseMirror node (`blockContainer`), so paragraphs,
 *   headings and code blocks are indistinguishable at the node level.
 * - `readonly AllowedChildType[]`: only these layout block types, enforced exactly
 *   by the schema. Naming a regular block type is a startup error; per-type
 *   regular-block filtering can be added to this same form later, with no API
 *   change.
 *
 * Neither form includes `placeable: "namedOnly"` types. Those appear only
 * where a parent names them explicitly in an array.
 */
export type ChildrenAllow = "blocks" | readonly AllowedChildType[];

/**
 * Which child blocks a layout block holds (`layoutOnly: true`), exposed as
 * `block.children` at runtime.
 *
 * The config describes one uniform set of children, semantically a single
 * implicit slot. Ordered multi-slot children (a `sequence` of slots) can be
 * added later as a sibling form.
 */
export type ChildrenConfig =
  | {
      /**
       * Any blocks, the default. When its last child is removed, the
       * layout block is removed too.
       */
      allow?: "blocks";
      /**
       * Layout block types the block does not hold, out of those placeable
       * anywhere: a column holds any block except a column list. Regular
       * block types can't be excluded, as every regular block is the same
       * ProseMirror node.
       */
      exclude?: readonly AllowedChildType[];
    }
  | {
      /** Which layout block types may appear as a child. */
      allow: readonly AllowedChildType[];
      /**
       * How few children the layout block may hold; `0` lets it be empty.
       * @default 1
       */
      min?: number;
      /**
       * Whether a layout block with too few children dissolves into what they
       * hold, like a column list with one column left. `false` keeps the
       * layout block and its empty children, like a tab set.
       * @default true
       */
      dissolve?: boolean;
    };

export interface BlockConfig<
  T extends string = string,
  PS extends PropSchema = PropSchema,
  C extends "inline" | "none" | "table" | "plain" =
    | "inline"
    | "none"
    | "table"
    | "plain",
> {
  /**
   * The type of the block (unique identifier within a schema)
   */
  type: T;
  /**
   * The properties that the block supports
   * @todo will be zod schema in the future
   */
  readonly propSchema: PS;
  /**
   * The content that the block supports
   */
  content: C;
  /**
   * `true` makes the block a layout block: a block without content of its own
   * (`content: "none"`) whose own node holds its child blocks. Its
   * `renderFrame` puts them in its slot (React: `slotRef`). With `false` (the
   * default), the block's child blocks are indented below it. Only a block
   * with `content: "none"` can set `true`.
   */
  layoutOnly?: C extends "none" ? boolean : false;
  /**
   * Which child blocks the block may have. Every block can have any child
   * blocks (`{ allow: "blocks" }`, the default). Only a layout block
   * (`layoutOnly: true`) can restrict them to certain types or a minimum
   * count, since the child blocks of other blocks all share one untyped
   * group. How the keyboard treats a block's children (e.g. whether Enter in
   * the block's text starts them) is set with its `experimental_keyboard`
   * settings.
   */
  children?: C extends "none"
    ? ChildrenConfig
    : {
        allow?: "blocks";
        exclude?: undefined;
        min?: undefined;
        dissolve?: undefined;
      };
  /**
   * Where this block may be placed.
   *
   * - `"anywhere"` (default): anywhere a regular block goes, the document
   *   root or nested under any other block.
   * - `"namedOnly"`: only inside a layout block that names this type in its
   *   `children.allow` array (e.g. a `column` inside a `columnList`).
   *
   * Only meaningful for layout blocks; regular blocks are always placeable
   * anywhere.
   */
  placeable?: "anywhere" | "namedOnly";
}

declare module "prosemirror-model" {
  interface NodeSpec {
    /**
     * The config of the BlockNote block this node was built from, so code
     * holding a bare `Node` can read block-level facts (like the content
     * kind) without an editor or schema reference. Set on every node built
     * from a block spec.
     */
    blockConfig?: BlockConfig;
  }
}

/**
 * BlockConfigOrCreator is a union type of BlockConfig and a function that returns a BlockConfig.
 * This is used to create block configs that can be passed to the createBlockSpec function.
 */
export type BlockConfigOrCreator<
  TName extends string = string,
  TProps extends PropSchema = PropSchema,
  TContent extends "inline" | "none" | "plain" = "inline" | "none" | "plain",
  TOptions extends Record<string, any> | undefined =
    | Record<string, any>
    | undefined,
> =
  | BlockConfig<TName, TProps, TContent>
  | (TOptions extends undefined
      ? () => BlockConfig<TName, TProps, TContent>
      : (options: Partial<TOptions>) => BlockConfig<TName, TProps, TContent>);

/**
 * ExtractBlockConfigFromConfigOrCreator is a helper type that extracts the BlockConfig type from a BlockConfigOrCreator.
 */
export type ExtractBlockConfigFromConfigOrCreator<
  ConfigOrCreator extends
    | BlockConfig<string, PropSchema, "inline" | "none" | "plain">
    | ((
        ...args: any[]
      ) => BlockConfig<string, PropSchema, "inline" | "none" | "plain">),
> = ConfigOrCreator extends (...args: any[]) => infer Config
  ? Config
  : ConfigOrCreator;

// restrict content to "inline" and "none" only
export type CustomBlockConfig<
  T extends string = string,
  PS extends PropSchema = PropSchema,
  C extends "inline" | "none" | "plain" = "inline" | "none" | "plain",
> = BlockConfig<T, PS, C>;

// A Spec contains both the Config and Implementation
export type BlockSpec<
  T extends string = string,
  PS extends PropSchema = PropSchema,
  C extends "inline" | "none" | "table" | "plain" =
    | "inline"
    | "none"
    | "table"
    | "plain",
> = {
  config: BlockConfig<T, PS, C>;
  implementation: BlockImplementation<T, PS, C>;
  extensions?: (Extension | ExtensionFactoryInstance)[];
};

/**
 * BlockSpecOrCreator is a union type of BlockSpec and a function that returns a BlockSpec.
 * This is used to create block specs that can be passed to the createBlockSpec function.
 */
export type BlockSpecOrCreator<
  T extends string = string,
  PS extends PropSchema = PropSchema,
  C extends "inline" | "none" | "table" | "plain" =
    | "inline"
    | "none"
    | "table"
    | "plain",
  TOptions extends Record<string, any> | undefined =
    | Record<string, any>
    | undefined,
> =
  | BlockSpec<T, PS, C>
  | (TOptions extends undefined
      ? () => BlockSpec<T, PS, C>
      : (options: Partial<TOptions>) => BlockSpec<T, PS, C>);

/**
 * ExtractBlockSpecFromSpecOrCreator is a helper type that extracts the BlockSpec type from a BlockSpecOrCreator.
 */
export type ExtractBlockSpecFromSpecOrCreator<
  SpecOrCreator extends
    | BlockSpec<string, PropSchema, "inline" | "none" | "plain">
    | ((
        ...args: any[]
      ) => BlockSpec<string, PropSchema, "inline" | "none" | "plain">),
> = SpecOrCreator extends (...args: any[]) => infer Spec ? Spec : SpecOrCreator;

/**
 * This allows de-coupling the types that we display to users versus the types we expose internally.
 *
 * This prevents issues with type-inference across parameters that Typescript cannot handle.
 * Specifically, the blocks shape cannot be properly inferred to a specific type like we expose to the user.
 */
export type LooseBlockSpec<
  T extends string = string,
  PS extends PropSchema = PropSchema,
  C extends "inline" | "none" | "table" | "plain" =
    | "inline"
    | "none"
    | "table"
    | "plain",
> = {
  config: BlockConfig<T, PS, C>;
  implementation: Omit<
    BlockImplementation<T, PS, C>,
    | "render"
    | "renderFrame"
    | "toExternalHTML"
    | "experimental_keyboard"
    | "meta"
  > & {
    /** Every keyboard setting of the block, with defaults filled in. */
    keyboard: (block: any) => BlockKeyboard;
    /** The block's `meta`, with defaults filled in. */
    meta: ResolvedBlockConfigMeta<T, PS>;
    // purposefully stub the types for render and toExternalHTML since they reference the block
    // A layout block declares `renderFrame` instead of `render`.
    render?: (
      /**
       * The custom block to render
       */
      block: any,
      /**
       * The BlockNote editor instance
       */
      editor: BlockNoteEditor<any>,
    ) => {
      dom: HTMLElement | DocumentFragment;
      contentDOM?: HTMLElement;
      ignoreMutation?: (mutation: ViewMutationRecord) => boolean;
      destroy?: () => void;
      update?: (node: PMNode) => boolean | void;
    };
    renderFrame?: <I extends InlineContentSchema, S extends StyleSchema>(
      block: any,
      editor: BlockNoteEditor<any, I, S>,
    ) =>
      | {
          dom: HTMLElement;
          slot: HTMLElement;
          /** Releases resources when the live frame is replaced or destroyed. */
          destroy?: () => void;
          update?: (block: any) => boolean | void;
        }
      | undefined;
    toExternalHTML?: (
      block: any,
      editor: BlockNoteEditor<any>,
      context: {
        nestingLevel: number;
      },
    ) =>
      | {
          dom: HTMLElement | DocumentFragment;
          contentDOM?: HTMLElement;
          childrenDOM?: HTMLElement;
        }
      | undefined;

    node: Node;
  };
  extensions?: (Extension | ExtensionFactoryInstance)[];
};

// Utility type. For a given object block schema, ensures that the key of each
// block spec matches the name of the TipTap node in it.
type NamesMatch<Blocks extends Record<string, BlockConfig>> = Blocks extends {
  [Type in keyof Blocks]: Type extends string
    ? Blocks[Type] extends { type: Type }
      ? Blocks[Type]
      : never
    : never;
}
  ? Blocks
  : never;

// A Schema contains all the types (Configs) supported in an editor
// The keys are the "type" of a block
export type BlockSchema = NamesMatch<Record<string, BlockConfig>>;

export type BlockSpecs = {
  [k in string]: {
    config: BlockSpec<k>["config"];
    implementation: Omit<
      BlockSpec<k>["implementation"],
      "render" | "renderFrame" | "toExternalHTML" | "experimental_keyboard"
    > & {
      experimental_keyboard?: BlockKeyboardOption<any>;
      // purposefully stub the types for render and toExternalHTML since they reference the block
      // A layout block declares `renderFrame` instead of `render`.
      render?: (
        /**
         * The custom block to render
         */
        block: any,
        /**
         * The BlockNote editor instance
         */
        editor: BlockNoteEditor<any>,
      ) => {
        dom: HTMLElement | DocumentFragment;
        contentDOM?: HTMLElement;
        ignoreMutation?: (mutation: ViewMutationRecord) => boolean;
        destroy?: () => void;
        update?: (node: PMNode) => boolean | void;
      };
      renderFrame?: <I extends InlineContentSchema, S extends StyleSchema>(
        block: any,
        editor: BlockNoteEditor<any, I, S>,
      ) =>
        | {
            dom: HTMLElement;
            slot: HTMLElement;
            /** Releases resources when the live frame is replaced or destroyed. */
            destroy?: () => void;
            update?: (block: any) => boolean | void;
          }
        | undefined;
      toExternalHTML?: (
        block: any,
        editor: BlockNoteEditor<any>,
        context: {
          nestingLevel: number;
        },
      ) =>
        | {
            dom: HTMLElement | DocumentFragment;
            contentDOM?: HTMLElement;
            childrenDOM?: HTMLElement;
          }
        | undefined;
    };
    extensions?: BlockSpec<k>["extensions"];
  };
};

export type BlockImplementations = Record<
  string,
  BlockImplementation<any, any>
>;

export type BlockSchemaFromSpecs<BS extends BlockSpecs> = {
  [K in keyof BS]: BS[K]["config"];
};

export type BlockSpecsFromSchema<BS extends BlockSchema> = {
  [K in keyof BS]: {
    config: BlockConfig<BS[K]["type"], BS[K]["propSchema"], BS[K]["content"]>;
    implementation: BlockImplementation<
      BS[K]["type"],
      BS[K]["propSchema"],
      BS[K]["content"]
    >;
    extensions?: (Extension | ExtensionFactoryInstance)[];
  };
};

export type BlockSchemaWithBlock<T extends string, C extends BlockConfig> = {
  [k in T]: C;
};

export type TableCellProps = {
  backgroundColor: string;
  textColor: string;
  textAlignment: "left" | "center" | "right" | "justify";
  colspan?: number;
  rowspan?: number;
};

export type TableCell<
  I extends InlineContentSchema,
  S extends StyleSchema = StyleSchema,
> = {
  type: "tableCell";
  props: TableCellProps;
  content: InlineContent<I, S>[];
};

export type TableContent<
  I extends InlineContentSchema,
  S extends StyleSchema = StyleSchema,
> = {
  type: "tableContent";
  columnWidths: (number | undefined)[];
  headerRows?: number;
  headerCols?: number;
  rows: {
    cells: InlineContent<I, S>[][] | TableCell<I, S>[];
  }[];
};

// The content of a block with "plain" content (e.g. a code block): unstyled
// text, represented as StyledText items whose `styles` is always empty.
export type PlainContent = (StyledText<{}> & {
  styles: Record<string, never>;
})[];

// Partial form of PlainContent: also accepts bare strings (both as the whole
// content and as array items), which are normalized on write.
export type PartialPlainContent =
  | string
  | (string | (StyledText<{}> & { styles: Record<string, never> }))[];

/**
 * The text of a block's `"plain"` content (e.g. a code block's source code).
 * Accepts the partial form too: block render/export paths can receive
 * `PartialBlock`s (e.g. the HTML serializers take them directly), where
 * plain content may still be the bare-string sugar.
 */
export function plainContentToString(
  content: PlainContent | PartialPlainContent,
): string {
  if (typeof content === "string") {
    return content;
  }

  return content
    .map((item) => (typeof item === "string" ? item : item.text))
    .join("");
}

// A BlockConfig has all the information to get the type of a Block (which is a specific instance of the BlockConfig.
// i.e.: paragraphConfig: BlockConfig defines what a "paragraph" is / supports, and BlockFromConfigNoChildren<paragraphConfig> is the shape of a specific paragraph block.
// (for internal use)
export type BlockFromConfigNoChildren<
  B extends BlockConfig,
  I extends InlineContentSchema,
  S extends StyleSchema,
> = {
  id: string;
  type: B["type"];
  props: Props<B["propSchema"]>;
  content: B["content"] extends "inline"
    ? InlineContent<I, S>[]
    : B["content"] extends "table"
      ? TableContent<I, S>
      : B["content"] extends "plain"
        ? PlainContent
        : B["content"] extends "none"
          ? undefined
          : never;
};

export type BlockFromConfig<
  B extends BlockConfig,
  I extends InlineContentSchema,
  S extends StyleSchema,
> = BlockFromConfigNoChildren<B, I, S> & {
  children: BlockNoDefaults<BlockSchema, I, S>[];
};

// Converts each block spec into a Block object without children. We later merge
// them into a union type and add a children property to create the Block and
// PartialBlock objects we use in the external API.
type BlocksWithoutChildren<
  BSchema extends BlockSchema,
  I extends InlineContentSchema,
  S extends StyleSchema,
> = {
  [BType in keyof BSchema]: BlockFromConfigNoChildren<BSchema[BType], I, S>;
};

// Converts each block spec into a Block object without children, merges them
// into a union type, and adds a children property
export type BlockNoDefaults<
  BSchema extends BlockSchema,
  I extends InlineContentSchema,
  S extends StyleSchema,
> = BlocksWithoutChildren<BSchema, I, S>[keyof BSchema] & {
  children: BlockNoDefaults<BSchema, I, S>[];
};

export type SpecificBlock<
  BSchema extends BlockSchema,
  BType extends keyof BSchema,
  I extends InlineContentSchema,
  S extends StyleSchema,
> = BlocksWithoutChildren<BSchema, I, S>[BType] & {
  children: BlockNoDefaults<BSchema, I, S>[];
};

/** CODE FOR PARTIAL BLOCKS, analogous to above
 *
 * Partial blocks are convenience-wrappers to make it easier to
 *create/update blocks in the editor.
 *
 */

export type PartialTableCell<
  I extends InlineContentSchema,
  S extends StyleSchema = StyleSchema,
> = {
  type: "tableCell";
  props?: Partial<TableCellProps>;
  content?: PartialInlineContent<I, S>;
};

export type PartialTableContent<
  I extends InlineContentSchema,
  S extends StyleSchema = StyleSchema,
> = {
  type: "tableContent";
  columnWidths?: (number | undefined)[];
  headerRows?: number;
  headerCols?: number;
  rows: {
    cells: PartialInlineContent<I, S>[] | PartialTableCell<I, S>[];
  }[];
};

type PartialBlockFromConfigNoChildren<
  B extends BlockConfig,
  I extends InlineContentSchema,
  S extends StyleSchema,
> = {
  id?: string;
  type?: B["type"];
  props?: Partial<Props<B["propSchema"]>>;
  content?: B["content"] extends "inline"
    ? PartialInlineContent<I, S>
    : B["content"] extends "table"
      ? PartialTableContent<I, S>
      : B["content"] extends "plain"
        ? PartialPlainContent
        : B["content"] extends "none"
          ? undefined
          : never;
};

type PartialBlocksWithoutChildren<
  BSchema extends BlockSchema,
  I extends InlineContentSchema,
  S extends StyleSchema,
> = {
  [BType in keyof BSchema]: PartialBlockFromConfigNoChildren<
    BSchema[BType],
    I,
    S
  >;
};

export type PartialBlockNoDefaults<
  BSchema extends BlockSchema,
  I extends InlineContentSchema,
  S extends StyleSchema,
> = PartialBlocksWithoutChildren<
  BSchema,
  I,
  S
>[keyof PartialBlocksWithoutChildren<BSchema, I, S>] &
  Partial<{
    children: PartialBlockNoDefaults<BSchema, I, S>[];
  }>;

export type SpecificPartialBlock<
  BSchema extends BlockSchema,
  I extends InlineContentSchema,
  BType extends keyof BSchema,
  S extends StyleSchema,
> = PartialBlocksWithoutChildren<BSchema, I, S>[BType] & {
  children?: BlockNoDefaults<BSchema, I, S>[];
};

export type PartialBlockFromConfig<
  B extends BlockConfig,
  I extends InlineContentSchema,
  S extends StyleSchema,
> = PartialBlockFromConfigNoChildren<B, I, S> & {
  children?: BlockNoDefaults<BlockSchema, I, S>[];
};

export type BlockIdentifier = { id: string } | string;

export type BlockImplementation<
  TName extends string = string,
  TProps extends PropSchema = PropSchema,
  TContent extends "inline" | "none" | "table" | "plain" =
    | "inline"
    | "none"
    | "table"
    | "plain",
> = {
  /**
   * @internal Framework adapter (React): draws the block's frame in the
   * editor, for the node view of a framed block's `blockContainer` or of a
   * layout block. Core uses it instead of the vanilla `renderFrame` when present.
   *
   * TODO: the content node view has no such hook yet: React builds it inside
   * `render` (see the `TODO` there). Add one, so `render` / `renderFrame`
   * only draw.
   */
  frameView?: (props: NodeViewRendererProps) => FrameView;
  /**
   * Metadata
   */
  meta?: BlockConfigMeta<TName, TProps>;
  /**
   * Experimental: how the keyboard treats the block and its children (Enter,
   * Shift-Enter, Backspace, and outdenting): the settings that differ from the
   * defaults, or a function of the block that returns them. See
   * {@link BlockKeyboard}. This API may change.
   */
  experimental_keyboard?: BlockKeyboardOption<
    BlockFromConfig<BlockConfig<TName, TProps, TContent>, any, any>
  >;
  /**
   * A function that converts the block into a DOM element. Every block
   * declares it, except a layout block (`layoutOnly: true`), which has no content
   * to draw and declares only `renderFrame`.
   *
   * FIXME: optional for every block here, checked at runtime
   * (`validateRenderHooks`). The types could require exactly one of `render`
   * and `renderFrame`, but core's first `createBlockSpec` overload can't see
   * `layoutOnly`.
   */
  render?: (
    this:
      | Record<string, never>
      | ({
          blockContentDOMAttributes: Record<string, string>;
          propSchema?: TProps;
        } & (
          | {
              renderType: "nodeView";
              props: NodeViewRendererProps;
            }
          | {
              renderType: "dom";
              props: undefined;
            }
        )),
    /**
     * The custom block to render
     */
    block: BlockFromConfig<BlockConfig<TName, TProps, TContent>, any, any>,
    /**
     * The BlockNote editor instance
     */
    editor: BlockNoteEditor<
      Record<TName, BlockConfig<TName, TProps, TContent>>
    >,
  ) => {
    dom: HTMLElement | DocumentFragment;
    contentDOM?: HTMLElement;
    ignoreMutation?: (mutation: ViewMutationRecord) => boolean;
    destroy?: () => void;
    /**
     * Called by ProseMirror when this block's node is updated (e.g. its content
     * or props change). Return `true` to handle the update in place - keeping
     * the existing DOM - or `false` to have the node view recreated via
     * `render`. When omitted, ProseMirror keeps the node view and reconciles its
     * `contentDOM` in place as long as the node type stays the same.
     *
     * Useful for blocks whose `render` builds custom DOM that needs to stay in
     * sync with the node (e.g. a code block rendering a preview of its content).
     */
    update?: (node: PMNode) => boolean | void;
  };

  /**
   * Draws the chrome *around* a block's content and children: the author's
   * markup wraps both, and the `slot` is where BlockNote mounts them.
   *
   * The slot holds the content first and the children after it. A layout block
   * (`layoutOnly: true`) has no content, so it draws only its frame, with its
   * child blocks in the slot. The frame's root is then the block's element,
   * and a layout block must always draw it.
   *
   * `render` stays the knob for the block's own content. A block may use
   * both: `render` draws the title, `renderFrame` draws the box around title
   * and body. Returning `undefined` declines — the block renders plain — so
   * a block can decide from its props, content, or children whether it is framed.
   *
   * Chrome outside the slot is the author's: ProseMirror leaves its events
   * alone. An `update` hook receives the current block on updates and patches
   * the frame in place. Return `false` to rebuild (or decline) the frame.
   * Without an update hook, a change to the block's props rebuilds the frame;
   * its content and children are in the slot, so typing doesn't. A frame
   * whose chrome shows the block's content or children needs an `update`
   * hook. Whether a block declines may depend only on its props: a declined
   * frame is asked again when the block's props change.
   */
  renderFrame?: <I extends InlineContentSchema, S extends StyleSchema>(
    this:
      | Record<string, never>
      | ({
          propSchema?: TProps;
        } & (
          | {
              renderType: "nodeView";
              props: NodeViewRendererProps;
            }
          | {
              renderType: "dom";
              props: undefined;
            }
        )),
    block: BlockFromConfig<BlockConfig<TName, TProps, TContent>, any, any>,
    editor: BlockNoteEditor<
      Record<TName, BlockConfig<TName, TProps, TContent>>,
      I,
      S
    >,
  ) =>
    | {
        dom: HTMLElement;
        /** Where BlockNote mounts the block's content and/or children. */
        slot: HTMLElement;
        /** Releases resources when the live frame is replaced or destroyed. */
        destroy?: () => void;
        update?: (
          block: BlockFromConfig<
            BlockConfig<TName, TProps, TContent>,
            any,
            any
          >,
        ) => boolean | void;
      }
    | undefined;

  /**
   * Exports block to external HTML. If not defined, the output will be the same
   * as `render(...).dom`, inside the block's frame (`renderFrame`) if it has
   * one. When defined, it replaces both.
   */
  toExternalHTML?: (
    this: Partial<{
      blockContentDOMAttributes: Record<string, string>;
      propSchema: TProps;
    }>,
    block: BlockFromConfig<BlockConfig<TName, TProps, TContent>, any, any>,
    editor: BlockNoteEditor<
      Record<TName, BlockConfig<TName, TProps, TContent>>
    >,
    context: {
      nestingLevel: number;
    },
  ) =>
    | {
        dom: HTMLElement | DocumentFragment;
        contentDOM?: HTMLElement;
        childrenDOM?: HTMLElement;
      }
    | undefined;

  /**
   * Parses an external HTML element into a block of this type when it returns the block props object, otherwise undefined
   */
  parse?: (el: HTMLElement) => Partial<Props<TProps>> | undefined;

  /**
   * The blocks that this block should run before.
   * This is used to determine the order in which blocks are parsed
   */
  runsBefore?: string[];

  /**
   * Advanced parsing function that controls how content within the block is parsed.
   * This is not recommended to use, and is only useful for advanced use cases.
   */
  parseContent?: (options: {
    el: HTMLElement;
    schema: Schema;
  }) => Fragment | undefined;
};

/**
 * BlockImplementationOrCreator is a union type of BlockImplementation and a function that returns a BlockImplementation.
 * This is used to create block implementations that can be passed to the createBlockSpec function.
 */
export type BlockImplementationOrCreator<
  ConfigOrCreator extends BlockConfigOrCreator = BlockConfigOrCreator,
  TOptions extends Record<string, any> | undefined =
    | Record<string, any>
    | undefined,
  Config extends ExtractBlockConfigFromConfigOrCreator<ConfigOrCreator> =
    ExtractBlockConfigFromConfigOrCreator<ConfigOrCreator>,
> =
  | BlockImplementation<Config["type"], Config["propSchema"], Config["content"]>
  | (TOptions extends undefined
      ? () => BlockImplementation<
          Config["type"],
          Config["propSchema"],
          Config["content"]
        >
      : (
          options: Partial<TOptions>,
        ) => BlockImplementation<
          Config["type"],
          Config["propSchema"],
          Config["content"]
        >);

/**
 * ExtractBlockImplementationFromImplementationOrCreator is a helper type that extracts the BlockImplementation type from a BlockImplementationOrCreator.
 */
export type ExtractBlockImplementationFromImplementationOrCreator<
  ImplementationOrCreator extends
    | BlockImplementation<string, PropSchema, "inline" | "none" | "plain">
    | ((
        ...args: any[]
      ) => BlockImplementation<
        string,
        PropSchema,
        "inline" | "none" | "plain"
      >),
> = ImplementationOrCreator extends (...args: any[]) => infer Implementation
  ? Implementation
  : ImplementationOrCreator;

// restrict content to "inline" and "none" only
export type CustomBlockImplementation<
  T extends string = string,
  PS extends PropSchema = PropSchema,
  C extends "inline" | "none" | "plain" = "inline" | "none" | "plain",
> = Omit<BlockImplementation<T, PS, C>, "frameView">;
