export const fa = {
  slash_menu: {
    heading: {
      title: "عنوان ۱",
      subtext: "عنوان سطح اول",
      aliases: ["عنوان", "تیتر", "عنوان۱", "تیتر۱"],
      group: "عنوان‌ها",
    },
    heading_2: {
      title: "عنوان ۲",
      subtext: "عنوان بخش اصلی",
      aliases: ["عنوان۲", "تیتر۲", "زیرعنوان"],
      group: "عنوان‌ها",
    },
    heading_3: {
      title: "عنوان ۳",
      subtext: "عنوان زیربخش و گروه",
      aliases: ["عنوان۳", "تیتر۳", "زیرتیتر"],
      group: "عنوان‌ها",
    },
    heading_4: {
      title: "عنوان ۴",
      subtext: "عنوان زیربخش فرعی",
      aliases: ["عنوان۴", "تیتر۴"],
      group: "زیرعنوان‌ها",
    },
    heading_5: {
      title: "عنوان ۵",
      subtext: "عنوان زیربخش کوچک",
      aliases: ["عنوان۵", "تیتر۵"],
      group: "زیرعنوان‌ها",
    },
    heading_6: {
      title: "عنوان ۶",
      subtext: "عنوان پایین‌ترین سطح",
      aliases: ["عنوان۶", "تیتر۶"],
      group: "زیرعنوان‌ها",
    },
    toggle_heading: {
      title: "عنوان تاشو ۱",
      subtext: "عنوان سطح اول با قابلیت تغییر وضعیت",
      aliases: ["عنوان تاشو", "تیتر تاشو", "عنوان۱ تاشو"],
      group: "زیرعنوان‌ها",
    },
    toggle_heading_2: {
      title: "عنوان تاشو ۲",
      subtext: "عنوان بخش اصلی با قابلیت تغییر وضعیت",
      aliases: ["عنوان۲ تاشو", "تیتر۲ تاشو"],
      group: "زیرعنوان‌ها",
    },
    toggle_heading_3: {
      title: "عنوان تاشو ۳",
      subtext: "عنوان زیربخش و گروه با قابلیت تغییر وضعیت",
      aliases: ["عنوان۳ تاشو", "تیتر۳ تاشو"],
      group: "زیرعنوان‌ها",
    },
    quote: {
      title: "نقل قول",
      subtext: "نقل قول یا گزیده",
      aliases: ["نقل قول", "کوت"],
      group: "بلوک‌های پایه",
    },
    toggle_list: {
      title: "فهرست تاشو",
      subtext: "فهرست با زیرمجموعه‌های پنهان‌شونده",
      aliases: ["فهرست تاشو", "فهرست تاشو"],
      group: "بلوک‌های پایه",
    },
    numbered_list: {
      title: "فهرست شماره‌دار",
      subtext: "فهرست با آیتم‌های مرتب",
      aliases: ["فهرست شماره دار", "فهرست عددی", "فهرست شماره دار"],
      group: "بلوک‌های پایه",
    },
    bullet_list: {
      title: "فهرست نشان‌دار",
      subtext: "فهرست با آیتم‌های نامرتب",
      aliases: ["فهرست", "فهرست نشان دار", "فهرست گلوله ای", "فهرست"],
      group: "بلوک‌های پایه",
    },
    check_list: {
      title: "بازینه",
      subtext: "فهرست با جعبه انتخاب",
      aliases: ["چک لیست", "لیست انجام کار", "لیست تیک دار", "بازینه"],
      group: "بلوک‌های پایه",
    },
    paragraph: {
      title: "پاراگراف",
      subtext: "بدنه سند شما",
      aliases: ["پاراگراف", "متن", "بند"],
      group: "بلوک‌های پایه",
    },
    code_block: {
      title: "بلوک کد",
      subtext: "بلوک کد با برجسته‌سازی نحو",
      aliases: ["کد", "بلوک کد", "برنامه"],
      group: "بلوک‌های پایه",
    },
    page_break: {
      title: "جداساز صفحه",
      subtext: "جداکننده صفحه",
      aliases: ["شکست صفحه", "صفحه جدید", "جداکننده"],
      group: "بلوک‌های پایه",
    },
    table: {
      title: "جدول",
      subtext: "جدول با سلول‌های قابل ویرایش",
      aliases: ["جدول"],
      group: "پیشرفته",
    },
    image: {
      title: "تصویر",
      subtext: "تصویر با قابلیت تغییر اندازه و زیرنویس",
      aliases: ["تصویر", "عکس", "آپلود تصویر", "مدیا", "لینک عکس"],
      group: "رسانه",
    },
    video: {
      title: "ویدیو",
      subtext: "ویدیو با قابلیت تغییر اندازه و زیرنویس",
      aliases: ["ویدیو", "فیلم", "آپلود ویدیو", "مدیا"],
      group: "رسانه",
    },
    audio: {
      title: "صوتی",
      subtext: "فایل صوتی جاسازی شده با زیرنویس",
      aliases: ["صوتی", "صدا", "آهنگ", "موسیقی", "آپلود صدا"],
      group: "رسانه",
    },
    file: {
      title: "فایل",
      subtext: "فایل جاسازی شده",
      aliases: ["فایل", "پرونده", "آپلود"],
      group: "رسانه",
    },
    emoji: {
      title: "شکلک",
      subtext: "جستجو و درج شکلک",
      aliases: ["ایموجی", "شکلک"],
      group: "دیگر",
    },
    divider: {
      title: "خط جداکننده",
      subtext: "جداسازی بصری بلوک‌ها",
      aliases: ["خط", "جداکننده", "خط افقی"],
      group: "بلوک‌های پایه",
    },
  },
  placeholders: {
    default: "متن وارد کنید یا برای دیدن دستورات '/' را تایپ کنید",
    heading: "عنوان",
    toggleListItem: "تاشو",
    bulletListItem: "فهرست",
    numberedListItem: "فهرست",
    checkListItem: "فهرست",
    emptyDocument: undefined,
    new_comment: "یک دیدگاه بنویسید...",
    edit_comment: "ویرایش دیدگاه...",
    comment_reply: "افزودن دیدگاه...",
  } as Record<string, string | undefined>,
  file_blocks: {
    add_button_text: {
      image: "افزودن تصویر",
      video: "افزودن ویدیو",
      audio: "افزودن صوت",
      file: "افزودن فایل",
    } as Record<string, string>,
  },
  toggle_blocks: {
    add_block_button: "تاشوی خالی. برای افزودن بلوک کلیک کنید.",
    toggle_button: "باز یا بسته کردن",
  },
  code_block: {
    add_source_button_text: "افزودن کد منبع",
    ok_button_text: "تأیید",
  },
  // from react package:
  side_menu: {
    add_block_label: "افزودن بلوک",
    drag_handle_label: "باز کردن منوی بلوک",
  },
  drag_handle: {
    delete_menuitem: "حذف",
    colors_menuitem: "رنگ‌ها",
    header_row_menuitem: "ردیف سرآیند",
    header_column_menuitem: "ستون سرآیند",
  },
  table_handle: {
    delete_column_menuitem: "حذف ستون",
    delete_row_menuitem: "حذف ردیف",
    add_left_menuitem: "افزودن ستون در چپ",
    add_right_menuitem: "افزودن ستون در راست",
    add_above_menuitem: "افزودن ردیف در بالا",
    add_below_menuitem: "افزودن ردیف در پایین",
    split_cell_menuitem: "تقسیم سلول",
    merge_cells_menuitem: "ادغام سلول‌ها",
    background_color_menuitem: "رنگ پس‌زمینه",
  },
  suggestion_menu: {
    no_items_title: "موردی یافت نشد",
  },
  color_picker: {
    text_title: "متن",
    background_title: "پس‌زمینه",
    colors: {
      default: "خودکار",
      gray: "خاکستری",
      brown: "قهوه‌ای",
      red: "قرمز",
      orange: "نارنجی",
      yellow: "زرد",
      green: "سبز",
      blue: "آبی",
      purple: "بنفش",
      pink: "صورتی",
    },
  },

  formatting_toolbar: {
    bold: {
      tooltip: "پررنگ",
      secondary_tooltip: "Mod+B",
    },
    italic: {
      tooltip: "کج",
      secondary_tooltip: "Mod+I",
    },
    underline: {
      tooltip: "زیرخط",
      secondary_tooltip: "Mod+U",
    },
    strike: {
      tooltip: "خط‌خوردگی",
      secondary_tooltip: "Mod+Shift+S",
    },
    code: {
      tooltip: "کد",
      secondary_tooltip: "",
    },
    colors: {
      tooltip: "رنگ‌ها",
    },
    link: {
      tooltip: "ایجاد لینک",
      secondary_tooltip: "Mod+K",
    },
    file_caption: {
      tooltip: "ویرایش زیرنویس",
      input_placeholder: "ویرایش زیرنویس",
    },
    file_replace: {
      tooltip: {
        image: "جایگزینی تصویر",
        video: "جایگزینی ویدیو",
        audio: "جایگزینی صوت",
        file: "جایگزینی فایل",
      } as Record<string, string>,
    },
    file_rename: {
      tooltip: {
        image: "تغییر نام تصویر",
        video: "تغییر نام ویدیو",
        audio: "تغییر نام صوت",
        file: "تغییر نام فایل",
      } as Record<string, string>,
      input_placeholder: {
        image: "تغییر نام تصویر",
        video: "تغییر نام ویدیو",
        audio: "تغییر نام صوت",
        file: "تغییر نام فایل",
      } as Record<string, string>,
    },
    file_download: {
      tooltip: {
        image: "دانلود تصویر",
        video: "دانلود ویدیو",
        audio: "دانلود صوت",
        file: "دانلود فایل",
      } as Record<string, string>,
    },
    file_delete: {
      tooltip: {
        image: "حذف تصویر",
        video: "حذف ویدیو",
        audio: "حذف صوت",
        file: "حذف فایل",
      } as Record<string, string>,
    },
    file_preview_toggle: {
      tooltip: "تغییر وضعیت پیش‌نمایش",
    },
    nest: {
      tooltip: "تودرتو کردن بلوک",
      secondary_tooltip: "Tab",
    },
    unnest: {
      tooltip: "خارج کردن بلوک از حالت تودرتو",
      secondary_tooltip: "Shift+Tab",
    },
    align_left: {
      tooltip: "تراز متن چپ",
    },
    align_center: {
      tooltip: "تراز متن وسط",
    },
    align_right: {
      tooltip: "تراز متن راست",
    },
    align_justify: {
      tooltip: "تراز متن دوطرفه",
    },
    table_cell_merge: {
      tooltip: "ادغام سلول‌ها",
    },
    comment: {
      tooltip: "افزودن دیدگاه",
    },
  },
  file_panel: {
    upload: {
      title: "بارگزاری",
      file_placeholder: {
        image: "بارگزاری تصویر",
        video: "بارگزاری ویدیو",
        audio: "بارگزاری صوت",
        file: "بارگزاری فایل",
      } as Record<string, string>,
      upload_error: "خطا: بارگزاری ناموفق بود",
    },
    embed: {
      title: "جاسازی",
      embed_button: {
        image: "جاسازی تصویر",
        video: "جاسازی ویدیو",
        audio: "جاسازی صوت",
        file: "جاسازی فایل",
      } as Record<string, string>,
      url_placeholder: "وارد کردن آدرس",
    },
  },
  link_toolbar: {
    delete: {
      tooltip: "حذف لینک",
    },
    edit: {
      text: "ویرایش لینک",
      tooltip: "ویرایش",
    },
    open: {
      tooltip: "باز کردن در تب جدید",
    },
    form: {
      title_placeholder: "ویرایش عنوان",
      url_placeholder: "ویرایش آدرس",
    },
  },
  comments: {
    edited: "ویرایش شده",
    save_button_text: "ذخیره",
    cancel_button_text: "لغو",
    deleted_reference_text: "محتوای اصلی حذف شد",
    discard_pending_comment:
      "آیا مطمئن هستید که می‌خواهید این دیدگاه را نادیده بگیرید؟",
    actions: {
      add_reaction: "افزودن واکنش",
      resolve: "حل کردن",
      reopen: "باز کردن مجدد",
      edit_comment: "ویرایش دیدگاه",
      delete_comment: "حذف دیدگاه",
      more_actions: "اقدامات بیشتر",
    },
    reactions: {
      reacted_by: "واکنش داده شده توسط",
    },
    sidebar: {
      marked_as_resolved: "به عنوان حل شده علامت‌گذاری شد",
      more_replies: (count: number) => `${count} پاسخ دیگر`,
    },
  },
  suggestion_changes: {
    formatting_change: "تغییر قالب‌بندی",
    deleted: "حذف\u200cشده",
    inserted: "درج\u200cشده",
    inserted_by: (users: string) => `درج‌شده توسط: ${users}`,
    deleted_by: (users: string) => `حذف‌شده توسط: ${users}`,
    changed: "تغییر\u200cیافته",
    changed_by: (users: string) => `تغییر\u200cیافته توسط: ${users}`,
    formatting_change_by: (formats: string, users: string) =>
      `تغییر قالب‌بندی (${formats}) توسط: ${users}`,
  },
  versioning: {
    start_of_document: "آغاز سند",
    compare_since_beginning_menuitem: "مقایسه از ابتدا",
    title: "تاریخچه",
    close: "بستن",
    show_named_only: "فقط نسخه‌های نام‌گذاری‌شده نمایش داده شود",
    show_all: "نمایش همه نسخه‌ها",
    comparison_on: "روشن کردن مقایسه",
    comparison_off: "خاموش کردن مقایسه",
    versions_list: "نسخه‌ها",
    empty: "هنوز نسخه‌ای وجود ندارد",
    empty_named_only: "نسخه‌ای با نام وجود ندارد",
    current_version: "نسخه فعلی",
    before_restore: "پیش از بازیابی",
    comparing_to: "مقایسه با",
    restored_from: (date: string) => `بازیابی‌شده از ${date}`,
    more_actions: "اقدامات بیشتر",
    version_name_input: "نام نسخه",
    name_version_menuitem: "نام‌گذاری این نسخه",
    rename_menuitem: "تغییر نام",
    compare_with_menuitem: "مقایسه با این نسخه",
    restore_menuitem: "بازیابی",
    delete_menuitem: "حذف",
    action_failed: "مشکلی پیش آمد. لطفاً دوباره تلاش کنید.",
    history_load_failed: "بارگیری تاریخچه نسخه‌ها ناموفق بود",
  },
  exporter: {
    open_file: "باز کردن فایل",
    open_video_file: "باز کردن ویدیو",
    open_audio_file: "باز کردن صدا",
  },
  generic: {
    loading: "در حال بارگیری...",
    load_more: "بارگیری بیشتر",
    ctrl_shortcut: "Ctrl",
    form_submit: "تأیید",
  },
};
