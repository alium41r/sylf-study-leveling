import { Mark, Node, Slice } from "@tiptap/pm/model";
import type { Block } from "../../blocks/defaultBlocks.js";
import { isLayoutNode } from "../../schema/blocks/children.js";
import UniqueID from "../../extensions/tiptap-extensions/UniqueID/UniqueID.js";
import type {
  BlockSchema,
  CustomInlineContentConfig,
  CustomInlineContentFromConfig,
  InlineContent,
  InlineContentFromConfig,
  InlineContentSchema,
  StyleSchema,
  Styles,
  TableCell,
  TableContent,
} from "../../schema/index.js";
import {
  isLinkInlineContent,
  isStyledTextInlineContent,
} from "../../schema/inlineContent/types.js";
import { UnreachableCaseError } from "../../util/typescript.js";
import {
  getBlockInfoFromNode,
  getNodeId,
  isSuggestedDeletionNode,
} from "../getBlockInfoFromPos.js";
import {
  getBlockCache,
  getBlockSchema,
  getInlineContentSchema,
  getStyleSchema,
} from "../pmUtil.js";

/**
 * The text of a plain content node. Plain content can't carry marks, so text
 * marked as deleted (in a version diff or a suggestion) would merge with its
 * replacement (e.g. `x^2` → `y^3` reads `xy^23`) - keep only the result.
 *
 * Styled text (`contentNodeToInlineContent`) still includes deleted text; see
 * the note there.
 *
 * TODO(suggestion mode): Do NOT keep this behavior when we implement suggestion
 * mode. Converting nodes to blocks must preserve pending suggestions, not
 * silently read deletions as accepted in `editor.document`, `onChange` or exports.
 * We only accept filtering here because plain text content has no good
 * representation of inline formatting, including insertion/deletion marks, and
 * merging both versions produces invalid preview source. Suggestion mode needs
 * to preserve that information and resolve the preview source separately.
 */
function plainContentText(node: Node): string {
  let text = "";
  node.forEach((child) => {
    if (!isSuggestedDeletionNode(child)) {
      text += child.textContent;
    }
  });
  return text;
}

/**
 * Converts an internal (prosemirror) table node contentto a BlockNote Tablecontent
 */
export function contentNodeToTableContent<
  I extends InlineContentSchema,
  S extends StyleSchema,
>(contentNode: Node, inlineContentSchema: I, styleSchema: S) {
  const ret: TableContent<I, S> = {
    type: "tableContent",
    columnWidths: [],
    headerRows: undefined,
    headerCols: undefined,
    rows: [],
  };

  /**
   * A matrix of boolean values indicating whether a cell is a header.
   * The first index is the row index, the second index is the cell index.
   */
  const headerMatrix: boolean[][] = [];

  contentNode.content.forEach((rowNode, _offset, rowIndex) => {
    const row: TableContent<I, S>["rows"][0] = {
      cells: [],
    };

    if (rowIndex === 0) {
      rowNode.content.forEach((cellNode) => {
        let colWidth = cellNode.attrs.colwidth as null | undefined | number[];
        if (colWidth === undefined || colWidth === null) {
          colWidth = new Array(cellNode.attrs.colspan ?? 1).fill(undefined);
        }
        ret.columnWidths.push(...colWidth);
      });
    }

    row.cells = rowNode.content.content.map((cellNode, cellIndex) => {
      if (!headerMatrix[rowIndex]) {
        headerMatrix[rowIndex] = [];
      }
      // Mark the cell as a header if it is a tableHeader node.
      headerMatrix[rowIndex][cellIndex] = cellNode.type.name === "tableHeader";
      // Convert cell content to inline content and merge adjacent styled text nodes
      const content = cellNode.content.content
        .map((child) =>
          contentNodeToInlineContent(child, inlineContentSchema, styleSchema),
        )
        // The reason that we merge this content is that we allow table cells to contain multiple tableParagraph nodes
        // So that we can leverage prosemirror-tables native merging
        // If the schema only allowed a single tableParagraph node, then the merging would not work and cause prosemirror to fit the content into a new cell
        .reduce(
          (acc, contentPartial) => {
            if (!acc.length) {
              return contentPartial;
            }

            const last = acc[acc.length - 1];
            const first = contentPartial[0];

            // Only merge if the last and first content are both styled text nodes and have the same styles
            if (
              first &&
              isStyledTextInlineContent(last) &&
              isStyledTextInlineContent(first) &&
              JSON.stringify(last.styles) === JSON.stringify(first.styles)
            ) {
              // Join them together if they have the same styles
              last.text += "\n" + first.text;
              acc.push(...contentPartial.slice(1));
              return acc;
            }
            acc.push(...contentPartial);
            return acc;
          },
          [] as InlineContent<I, S>[],
        );

      return {
        type: "tableCell",
        content,
        props: {
          colspan: cellNode.attrs.colspan,
          rowspan: cellNode.attrs.rowspan,
          backgroundColor: cellNode.attrs.backgroundColor,
          textColor: cellNode.attrs.textColor,
          textAlignment: cellNode.attrs.textAlignment,
        },
      } satisfies TableCell<I, S>;
    });

    ret.rows.push(row);
  });

  for (let i = 0; i < headerMatrix.length; i++) {
    if (headerMatrix[i]?.every((isHeader) => isHeader)) {
      ret.headerRows = (ret.headerRows ?? 0) + 1;
    }
  }

  for (let i = 0; i < headerMatrix[0]?.length; i++) {
    if (headerMatrix?.every((row) => row[i])) {
      ret.headerCols = (ret.headerCols ?? 0) + 1;
    }
  }

  return ret;
}

/**
 * Converts an internal (prosemirror) content node to a BlockNote InlineContent array.
 */
export function contentNodeToInlineContent<
  I extends InlineContentSchema,
  S extends StyleSchema,
>(contentNode: Node, inlineContentSchema: I, styleSchema: S) {
  const content: InlineContent<any, S>[] = [];
  let currentContent: InlineContent<any, S> | undefined = undefined;

  // NOTE: unlike plain content (`plainContentText`), text marked as deleted in
  // a version diff or suggestion is kept here, merged with its replacement. We
  // might want to filter it too, but that changes what `editor.document`,
  // `onChange` and exports report while suggestions show, and makes a block
  // whose text is all deleted read as empty.

  // Most of the logic below is for handling links because in ProseMirror links are marks
  // while in BlockNote links are a type of inline content
  contentNode.content.forEach((node) => {
    // hardBreak nodes do not have an InlineContent equivalent, instead we
    // add a newline to the previous node.
    if (node.type.name === "hardBreak") {
      if (currentContent) {
        // Current content exists.
        if (isStyledTextInlineContent(currentContent)) {
          // Current content is text.
          currentContent.text += "\n";
        } else if (isLinkInlineContent(currentContent)) {
          // Current content is a link.
          currentContent.content[currentContent.content.length - 1].text +=
            "\n";
        } else {
          throw new Error("unexpected");
        }
      } else {
        // Current content does not exist.
        currentContent = {
          type: "text",
          text: "\n",
          styles: {},
        };
      }

      return;
    }

    if (node.type.name !== "link" && node.type.name !== "text") {
      if (!inlineContentSchema[node.type.name]) {
        // eslint-disable-next-line no-console
        console.warn("unrecognized inline content type", node.type.name);
        return;
      }
      if (currentContent) {
        content.push(currentContent);
        currentContent = undefined;
      }

      content.push(
        nodeToCustomInlineContent(node, inlineContentSchema, styleSchema),
      );

      return;
    }

    const styles: Styles<S> = {};
    let linkMark: Mark | undefined;

    for (const mark of node.marks) {
      if (mark.type.name === "link") {
        linkMark = mark;
      } else {
        const config = styleSchema[mark.type.name];
        if (!config) {
          if (mark.type.spec.blocknoteIgnore) {
            // at this point, we don't want to show certain marks (such as comments)
            // in the BlockNote JSON output. These marks should be tagged with "blocknoteIgnore" in the spec
            continue;
          }
          throw new Error(`style ${mark.type.name} not found in styleSchema`);
        }
        if (config.propSchema === "boolean") {
          (styles as any)[config.type] = true;
        } else if (config.propSchema === "string") {
          (styles as any)[config.type] = mark.attrs.stringValue;
        } else {
          throw new UnreachableCaseError(config.propSchema);
        }
      }
    }

    // Parsing links and text.
    // Current content exists.
    if (currentContent) {
      // Current content is text.
      if (isStyledTextInlineContent(currentContent)) {
        if (!linkMark) {
          // Node is text (same type as current content).
          if (
            JSON.stringify(currentContent.styles) === JSON.stringify(styles)
          ) {
            // Styles are the same.
            currentContent.text += node.textContent;
          } else {
            // Styles are different.
            content.push(currentContent);
            currentContent = {
              type: "text",
              text: node.textContent,
              styles,
            };
          }
        } else {
          // Node is a link (different type to current content).
          content.push(currentContent);
          currentContent = {
            type: "link",
            href: linkMark.attrs.href,
            content: [
              {
                type: "text",
                text: node.textContent,
                styles,
              },
            ],
          };
        }
      } else if (isLinkInlineContent(currentContent)) {
        // Current content is a link.
        if (linkMark) {
          // Node is a link (same type as current content).
          // Link URLs are the same.
          if (currentContent.href === linkMark.attrs.href) {
            // Styles are the same.
            if (
              JSON.stringify(
                currentContent.content[currentContent.content.length - 1]
                  .styles,
              ) === JSON.stringify(styles)
            ) {
              currentContent.content[currentContent.content.length - 1].text +=
                node.textContent;
            } else {
              // Styles are different.
              currentContent.content.push({
                type: "text",
                text: node.textContent,
                styles,
              });
            }
          } else {
            // Link URLs are different.
            content.push(currentContent);
            currentContent = {
              type: "link",
              href: linkMark.attrs.href,
              content: [
                {
                  type: "text",
                  text: node.textContent,
                  styles,
                },
              ],
            };
          }
        } else {
          // Node is text (different type to current content).
          content.push(currentContent);
          currentContent = {
            type: "text",
            text: node.textContent,
            styles,
          };
        }
      } else {
        // TODO
      }
    }
    // Current content does not exist.
    else {
      // Node is text.
      if (!linkMark) {
        currentContent = {
          type: "text",
          text: node.textContent,
          styles,
        };
      }
      // Node is a link.
      else {
        currentContent = {
          type: "link",
          href: linkMark.attrs.href,
          content: [
            {
              type: "text",
              text: node.textContent,
              styles,
            },
          ],
        };
      }
    }
  });

  if (currentContent) {
    content.push(currentContent);
  }

  return content as InlineContent<I, S>[];
}

export function nodeToCustomInlineContent<
  I extends InlineContentSchema,
  S extends StyleSchema,
>(node: Node, inlineContentSchema: I, styleSchema: S): InlineContent<I, S> {
  if (node.type.name === "text" || node.type.name === "link") {
    throw new Error("unexpected");
  }
  const props: any = {};
  const icConfig = inlineContentSchema[
    node.type.name
  ] as CustomInlineContentConfig;
  for (const [attr, value] of Object.entries(node.attrs)) {
    if (!icConfig) {
      throw Error("ic node is of an unrecognized type: " + node.type.name);
    }

    const propSchema = icConfig.propSchema;

    if (attr in propSchema) {
      props[attr] = value;
    }
  }

  let content: CustomInlineContentFromConfig<any, any>["content"];

  if (icConfig.content === "styled") {
    content = contentNodeToInlineContent(
      node,
      inlineContentSchema,
      styleSchema,
    ) as any; // TODO: is this safe? could we have Links here that are undesired?
  } else if (icConfig.content === "plain") {
    // Plain inline content is a single unstyled string.
    content = plainContentText(node) as any;
  } else {
    content = undefined;
  }

  const ic = {
    type: node.type.name,
    props,
    content,
  } as InlineContentFromConfig<I[keyof I], S>;
  return ic;
}

/**
 * Convert a Prosemirror node to a BlockNote block.
 */
export function nodeToBlock<
  BSchema extends BlockSchema,
  I extends InlineContentSchema,
  S extends StyleSchema,
>(node: Node, doc: Node): Block<BSchema, I, S> {
  const schema = node.type.schema;
  const blockSchema = getBlockSchema(schema) as BSchema;
  const inlineContentSchema = getInlineContentSchema(schema) as I;
  const styleSchema = getStyleSchema(schema) as S;
  const blockCache = getBlockCache(schema);
  if (!node.type.isInGroup("bnBlock")) {
    throw Error("Node should be a block, but is instead: " + node.type.name);
  }

  const cachedBlock = blockCache?.get(node);

  if (cachedBlock) {
    return cachedBlock;
  }

  const blockInfo = getBlockInfoFromNode(node, 0);

  let id: string;
  try {
    id = getNodeId(blockInfo.block.node, doc);
  } catch {
    // Only used for blocks converted from other formats.
    id = UniqueID.options.generateID();
  }

  const blockConfig = blockSchema[blockInfo.blockNoteType];

  if (!blockConfig) {
    throw Error("Block is of an unrecognized type: " + blockInfo.blockNoteType);
  }

  const props: any = {};
  for (const [attr, value] of Object.entries({
    ...node.attrs,
    ...(blockInfo.hasContent ? blockInfo.content.node.attrs : {}),
  })) {
    const propSchema = blockConfig.propSchema;

    if (
      attr in propSchema &&
      !(propSchema[attr].default === undefined && value === undefined)
    ) {
      props[attr] = value;
    }
  }

  const children: Block<BSchema, I, S>[] = [];
  blockInfo.children?.node.forEach((child) => {
    children.push(nodeToBlock(child, doc));
  });

  let content: Block<any, any, any>["content"];

  // BlockInfo has already established whether content exists and its kind.
  // Conversion only interprets that content; it does not resolve shape again.
  switch (blockInfo.contentKind) {
    case "inline":
      content = contentNodeToInlineContent(
        blockInfo.content.node,
        inlineContentSchema,
        styleSchema,
      );
      break;
    case "table":
      content = contentNodeToTableContent(
        blockInfo.content.node,
        inlineContentSchema,
        styleSchema,
      );
      break;
    case "plain": {
      // Plain content is a single unstyled text item; an empty block is an
      // empty array, matching inline content.
      const text = plainContentText(blockInfo.content.node);
      content = text.length > 0 ? [{ type: "text", text, styles: {} }] : [];
      break;
    }
    case "none":
    case undefined:
      content = undefined;
      break;
    default:
      throw new UnreachableCaseError(blockInfo);
  }

  const block = {
    id,
    type: blockConfig.type,
    props,
    content,
    children,
  } as Block<BSchema, I, S>;

  blockCache?.set(node, block);

  return block;
}

/**
 * Convert a Prosemirror document to a BlockNote document (array of blocks)
 */
export function docToBlocks<
  BSchema extends BlockSchema,
  I extends InlineContentSchema,
  S extends StyleSchema,
>(doc: Node) {
  const blocks: Block<BSchema, I, S>[] = [];
  if (doc.firstChild) {
    doc.firstChild.descendants((node) => {
      blocks.push(nodeToBlock(node, doc));
      return false;
    });
  }
  return blocks;
}

/**
 *
 * Parse a Prosemirror Slice into a BlockNote selection. The prosemirror schema looks like this:
 *
 * <blockGroup>
 *   <blockContainer> (main content of block)
 *       <p, heading, etc.>
 *   <blockGroup> (only if blocks has children)
 *     <blockContainer> (child block)
 *       <p, heading, etc.>
 *     </blockContainer>
 *    <blockContainer> (child block 2)
 *       <p, heading, etc.>
 *     </blockContainer>
 *   </blockContainer>
 *  </blockGroup>
 * </blockGroup>
 *
 */
export function prosemirrorSliceToSlicedBlocks<
  BSchema extends BlockSchema,
  I extends InlineContentSchema,
  S extends StyleSchema,
>(
  slice: Slice,
): {
  /**
   * The blocks that are included in the selection.
   */
  blocks: Block<BSchema, I, S>[];
  /**
   * If a block was "cut" at the start of the selection, this will be the id of the block that was cut.
   */
  blockCutAtStart: string | undefined;
  /**
   * If a block was "cut" at the end of the selection, this will be the id of the block that was cut.
   */
  blockCutAtEnd: string | undefined;
} {
  // console.log(JSON.stringify(slice.toJSON()));
  function processNode(
    node: Node,
    openStart: number,
    openEnd: number,
  ): {
    blocks: Block<BSchema, I, S>[];
    blockCutAtStart: string | undefined;
    blockCutAtEnd: string | undefined;
  } {
    // Both `blockGroup` and layout block nodes (columnList, column, callout,
    // ...) hold block children directly, so both can be processed here.
    if (node.type.name !== "blockGroup" && !isLayoutNode(node.type)) {
      throw new Error("unexpected");
    }
    const blocks: Block<BSchema, I, S>[] = [];
    let blockCutAtStart: string | undefined;
    let blockCutAtEnd: string | undefined;

    // Each child is a block's node: a `blockContainer` for a regular block,
    // or a layout block node (columnList, column, callout, ...) for a layout block
    // block.
    node.forEach((blockNode, _offset, index) => {
      const isFirstBlock = index === 0;
      const isLastBlock = index === node.childCount - 1;

      const isLayoutBlock = isLayoutNode(blockNode.type);
      if (!isLayoutBlock) {
        if (blockNode.type.name !== "blockContainer") {
          throw new Error("unexpected");
        }
        if (blockNode.childCount === 0) {
          return;
        }
        if (blockNode.childCount > 2) {
          throw new Error(
            "unexpected, blockContainer.childCount: " + blockNode.childCount,
          );
        }
      }

      const omittedParent =
        !isLayoutBlock && blockNode.firstChild!.type.name === "blockGroup";
      if (omittedParent && !isFirstBlock) {
        throw new Error("unexpected");
      }

      // Open layout blocks and regular parents whose content was cut away both
      // contribute their selected children, without their own wrapper.
      if (
        omittedParent ||
        (isLayoutBlock &&
          ((isFirstBlock && openStart > 0) || (isLastBlock && openEnd > 0)))
      ) {
        const ret = processNode(
          isLayoutBlock ? blockNode : blockNode.firstChild!,
          isFirstBlock ? Math.max(0, openStart - 1) : 0,
          isLastBlock ? Math.max(0, openEnd - 1) : 0,
        );
        if (isFirstBlock) {
          blockCutAtStart = ret.blockCutAtStart;
        }
        if (isLastBlock) {
          blockCutAtEnd = ret.blockCutAtEnd;
        }
        blocks.push(...ret.blocks);
        return;
      }

      if (isLayoutBlock) {
        blocks.push(
          nodeToBlock<BSchema, I, S>(blockNode, slice.content.firstChild!),
        );
        return;
      }

      const block = nodeToBlock(blockNode, slice.content.firstChild!);
      const childGroup =
        blockNode.childCount > 1 ? blockNode.child(1) : undefined;

      let childBlocks: Block<BSchema, I, S>[] = [];
      if (childGroup) {
        const ret = processNode(
          childGroup,
          0, // TODO: can this be anything other than 0?
          isLastBlock ? Math.max(0, openEnd - 1) : 0,
        );
        childBlocks = ret.blocks;
        if (isLastBlock) {
          blockCutAtEnd = ret.blockCutAtEnd;
        }
      }

      if (isLastBlock && !childGroup && openEnd > 1) {
        blockCutAtEnd = block.id;
      }

      if (isFirstBlock && openStart > 1) {
        blockCutAtStart = block.id;
      }

      blocks.push({
        ...(block as any),
        children: childBlocks,
      });
    });

    return { blocks, blockCutAtStart, blockCutAtEnd };
  }

  if (slice.content.childCount === 0) {
    return {
      blocks: [],
      blockCutAtStart: undefined,
      blockCutAtEnd: undefined,
    };
  }

  if (slice.content.childCount !== 1) {
    throw new Error(
      "slice must be a single block, did you forget includeParents=true?",
    );
  }

  return processNode(
    slice.content.firstChild!,
    Math.max(slice.openStart - 1, 0),
    Math.max(slice.openEnd - 1, 0),
  );
}
