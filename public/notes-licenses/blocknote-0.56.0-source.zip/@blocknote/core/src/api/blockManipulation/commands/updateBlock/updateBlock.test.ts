import { describe, expect, it } from "vite-plus/test";

import type { PartialBlock } from "../../../../blocks/defaultBlocks.js";
import { getBlockInfoFromNode } from "../../../getBlockInfoFromPos.js";
import { getNodeById } from "../../../nodeUtil.js";
import { layoutSchema } from "../../layoutBlocks/layoutBlocks.fixture.js";
import { setupTestEnv } from "../../setupTestEnv.js";
import { updateBlock } from "./updateBlock.js";

const getEditor = setupTestEnv();

describe("Test updateBlock typing", () => {
  it("Type is inferred correctly", () => {
    try {
      getEditor().updateBlock(
        { id: "placeholder-id" },
        {
          // @ts-expect-error invalid type
          type: "non-existing",
        },
      );
    } catch {
      // ID doesn't exist, which is fine - this is a compile-time check
    }
  });

  it("Props are inferred correctly", () => {
    try {
      getEditor().updateBlock(
        { id: "placeholder-id" },
        {
          type: "paragraph",
          props: {
            // @ts-expect-error invalid type
            level: 1,
          },
        },
      );
    } catch {
      // ID doesn't exist, which is fine - this is a compile-time check
    }
    try {
      getEditor().updateBlock(
        { id: "placeholder-id" },
        {
          type: "heading",
          props: {
            level: 1,
          },
        },
      );
    } catch {
      // ID doesn't exist, which is fine - this is a compile-time check
    }
  });
});

describe("Test updateBlock", () => {
  it.skip("Update ID", () => {
    expect(
      getEditor().transact((tr) =>
        updateBlock(tr, "heading-with-everything", {
          id: "new-id",
        }),
      ),
    ).toMatchSnapshot();
    expect(getEditor().document).toMatchSnapshot();
  });

  it("Update type", () => {
    expect(
      getEditor().transact((tr) =>
        updateBlock(tr, "heading-with-everything", {
          type: "paragraph",
        }),
      ),
    ).toMatchSnapshot();

    expect(getEditor().document).toMatchSnapshot();
  });

  it("Update single prop", () => {
    expect(
      getEditor().transact((tr) =>
        updateBlock(tr, "heading-with-everything", {
          props: {
            level: 3,
          },
        }),
      ),
    ).toMatchSnapshot();

    expect(getEditor().document).toMatchSnapshot();
  });

  it("Update all props", () => {
    expect(
      getEditor().transact((tr) =>
        updateBlock(tr, "heading-with-everything", {
          props: {
            backgroundColor: "blue",
            level: 3,
            textAlignment: "right",
            textColor: "blue",
          },
        }),
      ),
    ).toMatchSnapshot();

    expect(getEditor().document).toMatchSnapshot();
  });

  it("Revert single prop", () => {
    expect(
      getEditor().transact((tr) =>
        updateBlock(tr, "heading-with-everything", {
          props: {
            level: undefined,
          },
        }),
      ),
    ).toMatchSnapshot();

    expect(getEditor().document).toMatchSnapshot();
  });

  it("Revert all props", () => {
    expect(
      getEditor().transact((tr) =>
        updateBlock(tr, "heading-with-everything", {
          props: {
            backgroundColor: undefined,
            level: undefined,
            textAlignment: undefined,
            textColor: undefined,
          },
        }),
      ),
    ).toMatchSnapshot();

    expect(getEditor().document).toMatchSnapshot();
  });

  it("Update with plain content", () => {
    expect(
      getEditor().transact((tr) =>
        updateBlock(tr, "heading-with-everything", {
          content: "New content",
        }),
      ),
    ).toMatchSnapshot();

    expect(getEditor().document).toMatchSnapshot();
  });

  it("Update with styled content", () => {
    expect(
      getEditor().transact((tr) =>
        updateBlock(tr, "heading-with-everything", {
          content: [
            {
              type: "text",
              text: "New",
              styles: { backgroundColor: "blue" },
            },
            { type: "text", text: " ", styles: {} },
            {
              type: "text",
              text: "content",
              styles: { backgroundColor: "blue" },
            },
          ],
        }),
      ),
    ).toMatchSnapshot();

    expect(getEditor().document).toMatchSnapshot();
  });

  it("Update partial (offset start)", () => {
    const posInfo = getNodeById(
      "heading-with-everything",
      getEditor().prosemirrorState.doc,
    )!;
    const info = getBlockInfoFromNode(posInfo.node, posInfo.posBeforeNode);

    if (!info.hasContent) {
      throw new Error("heading-with-everything is not a block container");
    }

    getEditor().transact((tr) =>
      updateBlock(
        tr,
        "heading-with-everything",
        {
          content: [
            {
              type: "text",
              text: "without styles",
              styles: {},
            },
          ],
        },
        info.content.beforePos + 9,
      ),
    );

    expect(getEditor().document).toMatchSnapshot();
  });

  it("Update partial (offset start + end)", () => {
    const posInfo = getNodeById(
      "heading-with-everything",
      getEditor().prosemirrorState.doc,
    )!;
    const info = getBlockInfoFromNode(posInfo.node, posInfo.posBeforeNode);

    if (!info.hasContent) {
      throw new Error("heading-with-everything is not a block container");
    }

    getEditor().transact((tr) =>
      updateBlock(
        tr,
        "heading-with-everything",
        {
          content: [
            {
              type: "text",
              text: "without styles and ",
              styles: {},
            },
          ],
        },
        info.content.beforePos + 9,
        info.content.beforePos + 9,
      ),
    );

    expect(getEditor().document).toMatchSnapshot();
  });

  it("Update partial (props + offset end)", () => {
    const posInfo = getNodeById(
      "heading-with-everything",
      getEditor().prosemirrorState.doc,
    )!;
    const info = getBlockInfoFromNode(posInfo.node, posInfo.posBeforeNode);

    if (!info.hasContent) {
      throw new Error("heading-with-everything is not a block container");
    }

    getEditor().transact((tr) => {
      updateBlock(
        tr,
        "heading-with-everything",
        {
          props: {
            level: 1,
          },
          content: [
            {
              type: "text",
              text: "Title",
              styles: {},
            },
          ],
        },
        undefined,
        info.content.beforePos + 8,
      );
    });

    expect(getEditor().document).toMatchSnapshot();
  });

  it("Update partial (table cell)", () => {
    const posInfo = getNodeById("table-0", getEditor().prosemirrorState.doc)!;
    const info = getBlockInfoFromNode(posInfo.node, posInfo.posBeforeNode);

    if (!info.hasContent) {
      throw new Error("table-0 is not a block container");
    }

    const cell = info.content.node.resolve(2);

    getEditor().transact((tr) =>
      updateBlock(
        tr,
        "table-0",
        {
          type: "table",
          content: {
            type: "tableContent",
            rows: [{ cells: ["updated cell 1"] }],
          },
        },
        info.content.beforePos + 2,
        info.content.beforePos + 2 + cell.node().nodeSize,
      ),
    );

    expect(getEditor().document).toMatchSnapshot();
  });

  it("Update partial (table row)", () => {
    const posInfo = getNodeById("table-0", getEditor().prosemirrorState.doc)!;
    const info = getBlockInfoFromNode(posInfo.node, posInfo.posBeforeNode);

    if (!info.hasContent) {
      throw new Error("table-0 is not a block container");
    }

    const cell = info.content.node.resolve(1);

    getEditor().transact((tr) =>
      updateBlock(
        tr,
        "table-0",
        {
          type: "table",
          content: {
            type: "tableContent",
            rows: [
              {
                cells: ["updated cell 1", "updated cell 2", "updated cell 3"],
              },
            ],
          },
        },
        info.content.beforePos + 1,
        info.content.beforePos + 1 + cell.node().nodeSize,
      ),
    );

    expect(getEditor().document).toMatchSnapshot();
  });

  it("Update children", () => {
    expect(
      getEditor().transact((tr) =>
        updateBlock(tr, "heading-with-everything", {
          children: [
            {
              id: "new-nested-paragraph",
              type: "paragraph",
              content: "New nested Paragraph 2",
              children: [
                {
                  id: "new-double-nested-paragraph",
                  type: "paragraph",
                  content: "New double Nested Paragraph 2",
                },
              ],
            },
          ],
        }),
      ),
    ).toMatchSnapshot();

    expect(getEditor().document).toMatchSnapshot();
  });

  it.skip("Update everything", () => {
    expect(
      getEditor().transact((tr) =>
        updateBlock(tr, "heading-with-everything", {
          id: "new-id",
          type: "paragraph",
          props: {
            backgroundColor: "blue",
            textAlignment: "right",
            textColor: "blue",
          },
          content: [
            {
              type: "text",
              text: "New",
              styles: { backgroundColor: "blue" },
            },
            { type: "text", text: " ", styles: {} },
            {
              type: "text",
              text: "content",
              styles: { backgroundColor: "blue" },
            },
          ],
          children: [
            {
              id: "new-nested-paragraph",
              type: "paragraph",
              content: "New nested Paragraph 2",
              children: [
                {
                  id: "new-double-nested-paragraph",
                  type: "paragraph",
                  content: "New double Nested Paragraph 2",
                },
              ],
            },
          ],
        }),
      ),
    ).toMatchSnapshot();

    expect(getEditor().document).toMatchSnapshot();
  });

  it("Update inline content to empty table content", () => {
    expect(() => {
      getEditor().transact((tr) =>
        updateBlock(tr, "paragraph-0", {
          type: "table",
        }),
      );
    }).toThrow();
  });

  it("Update table content to empty inline content", () => {
    expect(
      getEditor().transact((tr) =>
        updateBlock(tr, "table-0", {
          type: "paragraph",
        }),
      ),
    ).toMatchSnapshot();

    expect(getEditor().document).toMatchSnapshot();
  });

  it("Update inline content to table content", () => {
    expect(
      getEditor().transact((tr) =>
        updateBlock(tr, "paragraph-0", {
          type: "table",
          content: {
            type: "tableContent",
            rows: [
              {
                cells: ["Cell 1", "Cell 2", "Cell 3"],
              },
              {
                cells: ["Cell 4", "Cell 5", "Cell 6"],
              },
              {
                cells: ["Cell 7", "Cell 8", "Cell 9"],
              },
            ],
          },
        }),
      ),
    ).toMatchSnapshot();

    expect(getEditor().document).toMatchSnapshot();
  });

  it("Update table content to inline content", () => {
    expect(
      getEditor().transact((tr) =>
        updateBlock(tr, "table-0", {
          type: "paragraph",
          content: "Paragraph",
        }),
      ),
    ).toMatchSnapshot();

    expect(getEditor().document).toMatchSnapshot();
  });

  it("Update inline content to no content", () => {
    expect(
      getEditor().transact((tr) =>
        updateBlock(tr, "paragraph-0", {
          type: "image",
        }),
      ),
    ).toMatchSnapshot();

    expect(getEditor().document).toMatchSnapshot();
  });

  it("Update inline content to plain content", () => {
    expect(
      getEditor().transact((tr) =>
        updateBlock(tr, "paragraph-0", {
          type: "codeBlock",
        }),
      ),
    ).toMatchSnapshot();

    expect(getEditor().document).toMatchSnapshot();
  });

  it("Update styled inline content to plain content", () => {
    // The plain block can't hold formatting marks, so the styling is dropped
    // but the text is preserved.
    expect(
      getEditor().transact((tr) =>
        updateBlock(tr, "paragraph-with-styled-content", {
          type: "codeBlock",
        }),
      ),
    ).toMatchSnapshot();

    expect(getEditor().document).toMatchSnapshot();
  });

  it("Update plain content to inline content", () => {
    getEditor().transact((tr) =>
      updateBlock(tr, "paragraph-0", { type: "codeBlock" }),
    );

    expect(
      getEditor().transact((tr) =>
        updateBlock(tr, "paragraph-0", {
          type: "paragraph",
        }),
      ),
    ).toMatchSnapshot();

    expect(getEditor().document).toMatchSnapshot();
  });

  it("Update no content to empty inline content", () => {
    expect(
      getEditor().transact((tr) =>
        updateBlock(tr, "image-0", {
          type: "paragraph",
        }),
      ),
    ).toMatchSnapshot();

    expect(getEditor().document).toMatchSnapshot();
  });

  it("Update no content to inline content", () => {
    expect(
      getEditor().transact((tr) =>
        updateBlock(tr, "image-0", {
          type: "paragraph",
          content: "Paragraph",
        }),
      ),
    ).toMatchSnapshot();

    expect(getEditor().document).toMatchSnapshot();
  });

  it("Update no content to empty table content", () => {
    expect(
      getEditor().transact((tr) =>
        updateBlock(tr, "image-0", {
          type: "table",
        }),
      ),
    ).toMatchSnapshot();

    expect(getEditor().document).toMatchSnapshot();
  });

  it("Update no content to table content", () => {
    expect(
      getEditor().transact((tr) =>
        updateBlock(tr, "image-0", {
          type: "table",
          content: {
            type: "tableContent",
            rows: [
              {
                cells: [
                  {
                    type: "tableCell",
                    content: ["Cell 1"],
                  },
                  {
                    type: "tableCell",
                    content: ["Cell 2"],
                    props: {
                      backgroundColor: "red",
                      colspan: 1,
                      rowspan: 1,
                      textAlignment: "right",
                      textColor: "red",
                    },
                  },
                  {
                    type: "tableCell",
                    content: ["Cell 3"],
                    props: {
                      backgroundColor: "default",
                      colspan: 1,
                      rowspan: 1,
                      textAlignment: "left",
                      textColor: "default",
                    },
                  },
                ],
              },
              {
                cells: ["Cell 4", "Cell 5", "Cell 6"],
              },
              {
                cells: ["Cell 7", "Cell 8", "Cell 9"],
              },
            ],
          },
        }),
      ),
    ).toMatchSnapshot();

    expect(getEditor().document).toMatchSnapshot();
  });

  it("Update table content to no content", () => {
    expect(
      getEditor().transact((tr) =>
        updateBlock(tr, "table-0", {
          type: "image",
        }),
      ),
    ).toMatchSnapshot();

    expect(getEditor().document).toMatchSnapshot();
  });
});

/**
 * These tests assert that `updateBlock` produces the smallest possible set of
 * ProseMirror steps, rather than replacing whole blocks/content/children when
 * only a small part changed.
 */
describe("Test updateBlock minimal steps", () => {
  // Runs `updateBlock` in a throwaway transaction and returns the resulting
  // steps as JSON for inspection.
  const getSteps = (blockId: string, update: PartialBlock<any, any, any>) => {
    let steps: any[] = [];
    getEditor().transact((tr) => {
      updateBlock(tr, blockId, update);
      steps = tr.steps.map((s) => s.toJSON());
    });
    return steps;
  };

  it("Changing a single prop emits only attr steps", () => {
    const steps = getSteps("heading-with-everything", {
      props: { level: 3 },
    });

    expect(steps).toEqual([
      {
        stepType: "attr",
        pos: expect.any(Number),
        attr: "level",
        value: 3,
      },
    ]);
  });

  it("Changing only children does not touch content or container", () => {
    const steps = getSteps("heading-with-everything", {
      children: [
        {
          id: "new-nested-paragraph",
          type: "paragraph",
          content: "New nested Paragraph 2",
        },
      ],
    });

    // A single replace step covering the children range only.
    expect(steps).toHaveLength(1);
    expect(steps[0].stepType).toBe("replace");
  });

  it("Appending a child is a pure insertion", () => {
    const steps = getSteps("heading-with-everything", {
      children: [
        // Existing child, kept as-is.
        {
          id: "nested-paragraph-1",
          type: "paragraph",
          content: "Nested Paragraph 1",
          children: [
            {
              id: "double-nested-paragraph-1",
              type: "paragraph",
              content: "Double Nested Paragraph 1",
            },
          ],
        },
        // New sibling.
        {
          id: "appended-child",
          type: "paragraph",
          content: "Appended",
        },
      ],
    });

    expect(steps).toHaveLength(1);
    expect(steps[0].stepType).toBe("replace");
    // Pure insertion: from === to (nothing deleted).
    expect(steps[0].from).toBe(steps[0].to);

    expect(
      (getEditor().getBlock("heading-with-everything") as any).children.map(
        (c: any) => c.id,
      ),
    ).toEqual(["nested-paragraph-1", "appended-child"]);
  });

  it("Changing part of the content only replaces the changed range", () => {
    // Original content: "Heading" + " with styled " + "content".
    // Only the middle text changes.
    const steps = getSteps("heading-with-everything", {
      content: [
        { type: "text", text: "Heading", styles: { bold: true } },
        { type: "text", text: " with NEW ", styles: {} },
        { type: "text", text: "content", styles: { italic: true } },
      ],
    });

    expect(steps).toHaveLength(1);
    const [step] = steps;
    expect(step.stepType).toBe("replace");
    // The replaced range should be the diff ("styled" -> "NEW"), much smaller
    // than the whole content node.
    expect(step.to - step.from).toBeLessThan(
      "Heading with styled content".length,
    );
    // Only the changed text is inserted.
    expect(step.slice.content[0].text).toBe("NEW");
  });

  it("Changing one table cell only replaces that cell's text", () => {
    const steps = getSteps("table-0", {
      type: "table",
      content: {
        type: "tableContent",
        rows: [
          { cells: ["Cell 1", "Cell 2", "Cell 3"] },
          { cells: ["Cell 4", "CHANGED", "Cell 6"] },
          { cells: ["Cell 7", "Cell 8", "Cell 9"] },
        ],
      },
    });

    expect(steps).toHaveLength(1);
    expect(steps[0].stepType).toBe("replace");

    const block = getEditor().getBlock("table-0") as any;
    expect(block.content.rows[1].cells[1].content[0].text).toBe("CHANGED");
    // Surrounding cells are untouched.
    expect(block.content.rows[0].cells[0].content[0].text).toBe("Cell 1");
    expect(block.content.rows[2].cells[2].content[0].text).toBe("Cell 9");
  });

  it("Updating with identical content/props/children emits no steps", () => {
    const steps = getSteps("heading-with-everything", {
      type: "heading",
      props: {
        backgroundColor: "red",
        level: 2,
        textAlignment: "center",
        textColor: "red",
      },
      content: [
        { type: "text", text: "Heading", styles: { bold: true } },
        { type: "text", text: " with styled ", styles: {} },
        { type: "text", text: "content", styles: { italic: true } },
      ],
    });

    expect(steps).toEqual([]);
  });

  it("Changing only a child's content replaces just that child's text", () => {
    const steps = getSteps("paragraph-with-children", {
      children: [
        {
          id: "nested-paragraph-0",
          type: "paragraph",
          content: "CHANGED nested",
          children: [
            {
              id: "double-nested-paragraph-0",
              type: "paragraph",
              content: "Double Nested Paragraph 0",
            },
          ],
        },
      ],
    });

    // Diffed down to a single replace; the unchanged double-nested child and
    // surrounding structure are left in place.
    expect(steps).toHaveLength(1);
    expect(steps[0].stepType).toBe("replace");

    const block = getEditor().getBlock("paragraph-with-children") as any;
    expect(block.children[0].content[0].text).toBe("CHANGED nested");
    expect(block.children[0].children[0].id).toBe("double-nested-paragraph-0");
    expect(block.children[0].children[0].content[0].text).toBe(
      "Double Nested Paragraph 0",
    );
  });

  it("Removing a table row only replaces the removed range", () => {
    const steps = getSteps("table-0", {
      type: "table",
      content: {
        type: "tableContent",
        rows: [
          { cells: ["Cell 1", "Cell 2", "Cell 3"] },
          { cells: ["Cell 7", "Cell 8", "Cell 9"] },
        ],
      },
    });

    // Snapped to the removed (middle) row: a single replace where content is
    // deleted (slice is empty -> from < to).
    expect(steps).toHaveLength(1);
    expect(steps[0].stepType).toBe("replace");
    expect(steps[0].to).toBeGreaterThan(steps[0].from);

    const block = getEditor().getBlock("table-0") as any;
    expect(block.content.rows).toHaveLength(2);
    expect(block.content.rows[0].cells[0].content[0].text).toBe("Cell 1");
    expect(block.content.rows[1].cells[2].content[0].text).toBe("Cell 9");
  });

  // Regression: when the content node's TYPE changes, setNodeMarkupMinimal
  // emits a ReplaceAroundStep. Mapping the original beforePos through that step
  // with the default (forward) bias pushes the position past the node, so the
  // subsequent content diff resolved into the wrong place and corrupted the doc.
  // The position must be mapped with a -1 (before) bias.
  it("Type change + content change keeps the document valid", () => {
    const steps = getSteps("paragraph-3", {
      type: "heading",
      props: { level: 1 },
      content: "Now a heading",
    });

    // The type change requires a ReplaceAroundStep, but no error should be
    // thrown and the resulting block must be correct.
    expect(steps.length).toBeGreaterThan(0);

    const block = getEditor().getBlock("paragraph-3") as any;
    expect(block.type).toBe("heading");
    expect(block.props.level).toBe(1);
    expect(block.content[0].text).toBe("Now a heading");

    // The editor document must still be internally consistent.
    expect(() => getEditor()._tiptapEditor.state.doc.check()).not.toThrow();
  });

  it("Type change followed by another update resolves positions correctly", () => {
    const editor = getEditor();

    // First: change the content-node type (forces a ReplaceAroundStep), which
    // is the operation that previously left later positions stale.
    editor.transact((tr) => {
      updateBlock(tr, "paragraph-4", {
        type: "heading",
        props: { level: 2 },
        content: "Heading four",
      });
    });

    // Then: a follow-up update on a *later* block, whose position would be wrong
    // if the first transaction had corrupted the doc length.
    expect(() => {
      editor.transact((tr) => {
        updateBlock(tr, "paragraph-9", {
          content: "Paragraph nine updated",
        });
      });
    }).not.toThrow();

    expect((editor.getBlock("paragraph-4") as any).type).toBe("heading");
    expect((editor.getBlock("paragraph-9") as any).content[0].text).toBe(
      "Paragraph nine updated",
    );
    expect(() => editor._tiptapEditor.state.doc.check()).not.toThrow();
  });

  // Strongest regression: a children change (adds a step BEFORE the content
  // node is updated) combined with a content-node type change (ReplaceAroundStep)
  // and a content change. This is the exact mix that left the original beforePos
  // stale; without the -1 mapping bias the content diff resolves into the wrong
  // place and corrupts/throws.
  it("Children change + type change + content change stays valid", () => {
    const editor = getEditor();

    expect(() => {
      editor.transact((tr) => {
        updateBlock(tr, "paragraph-with-children", {
          type: "heading",
          props: { level: 2 },
          content: "Converted to heading",
          children: [
            {
              id: "nested-paragraph-0",
              type: "paragraph",
              content: "Updated nested",
            },
            {
              id: "brand-new-child",
              type: "paragraph",
              content: "Brand new child",
            },
          ],
        });
      });
    }).not.toThrow();

    const block = editor.getBlock("paragraph-with-children") as any;
    expect(block.type).toBe("heading");
    expect(block.props.level).toBe(2);
    expect(block.content[0].text).toBe("Converted to heading");
    expect(block.children.map((c: any) => c.id)).toEqual([
      "nested-paragraph-0",
      "brand-new-child",
    ]);
    expect(block.children[0].content[0].text).toBe("Updated nested");
    expect(() => editor._tiptapEditor.state.doc.check()).not.toThrow();

    // A follow-up update on a later block must still resolve correctly.
    expect(() => {
      editor.transact((tr) => {
        updateBlock(tr, "paragraph-9", { content: "After conversion" });
      });
    }).not.toThrow();
    expect((editor.getBlock("paragraph-9") as any).content[0].text).toBe(
      "After conversion",
    );
  });

  it("Type change with offset content replace stays minimal and valid", () => {
    const editor = getEditor();
    const posInfo = getNodeById(
      "paragraph-with-styled-content",
      editor.prosemirrorState.doc,
    )!;
    const info = getBlockInfoFromNode(posInfo.node, posInfo.posBeforeNode);
    if (!info.hasContent) {
      throw new Error("paragraph-with-styled-content is not a block container");
    }

    // paragraph-with-styled-content is "Paragraph"(bold) + " with styled " +
    // "content"(italic). Replace only the unstyled middle node while converting
    // the block to a heading. The type change forces a ReplaceAroundStep, after
    // which the offset-replace branch must still resolve the (now shifted)
    // content position correctly.
    let steps: any[] = [];
    editor.transact((tr) => {
      updateBlock(
        tr,
        "paragraph-with-styled-content",
        {
          type: "heading",
          props: { level: 3 },
          content: [{ type: "text", text: " with NEW ", styles: {} }],
        },
        info.content.beforePos + 1 + "Paragraph".length,
        info.content.beforePos + 1 + "Paragraph with styled ".length,
      );
      steps = tr.steps.map((s) => s.toJSON());
    });

    expect(steps.length).toBeGreaterThan(0);

    const block = editor.getBlock("paragraph-with-styled-content") as any;
    expect(block.type).toBe("heading");
    expect(block.props.level).toBe(3);
    // The styled text on either side of the replaced range is preserved.
    expect(block.content[0].text).toBe("Paragraph");
    expect(block.content[block.content.length - 1].text).toBe("content");
    expect(() => editor._tiptapEditor.state.doc.check()).not.toThrow();
  });
});

// Changing a block's type across the content/layout block divide can't happen in
// place, so `updateBlock` rebuilds the node and has to decide what to do with
// the content the old shape held and the new one can't. These tests pin that
// decision. Assertions are explicit rather than snapshotted because the point
// is *where* the carried content ends up.
describe("Test updateBlock content carry-over", () => {
  const getLayoutEditor = setupTestEnv({
    schema: layoutSchema,
    document: [
      {
        id: "paragraph-with-text",
        type: "paragraph",
        content: "Paragraph with text",
      },
      {
        id: "empty-paragraph",
        type: "paragraph",
      },
      {
        id: "paragraph-with-text-and-children",
        type: "paragraph",
        content: "Parent text",
        children: [
          {
            id: "existing-child",
            type: "paragraph",
            content: "Existing child",
          },
        ],
      },
      {
        id: "table-0",
        type: "table",
        content: {
          type: "tableContent",
          rows: [{ cells: ["Cell 1", "Cell 2"] }],
        },
      },
      {
        id: "callout-0",
        type: "callout",
        children: [
          {
            id: "callout-child",
            type: "paragraph",
            content: "Callout child",
          },
        ],
      },
    ],
  });

  // A block that changes shape is rebuilt rather than updated in place. The
  // rebuilt block keeps its ID, so comments and other references to it stay
  // valid. Before, it got a new ID; the first and the last test check this.
  it("Moves inline content into a child paragraph when becoming a layout block", () => {
    const editor = getLayoutEditor();
    editor.transact((tr) =>
      updateBlock(tr, "paragraph-with-text", { type: "callout" }),
    );

    const block = editor.document[0] as any;
    expect(block.type).toBe("callout");
    expect(block.id).toBe("paragraph-with-text");
    expect(block.children).toHaveLength(1);
    expect(block.children[0].type).toBe("paragraph");
    expect(block.children[0].content).toEqual([
      { type: "text", text: "Paragraph with text", styles: {} },
    ]);
    expect(() => editor.prosemirrorState.doc.check()).not.toThrow();
  });

  it("Fills a layout block's children when there is no content to carry", () => {
    const editor = getLayoutEditor();
    editor.transact((tr) =>
      updateBlock(tr, "empty-paragraph", { type: "pair" }),
    );

    // An empty paragraph carries nothing, so the rebuilt node holds just the
    // empty fill its content expression requires — two callouts for the
    // pair's `min: 2`, each with the one empty block a callout needs.
    const block = editor.document[1] as any;
    expect(block.type).toBe("pair");
    expect(block.children.map((child: any) => child.type)).toEqual([
      "callout",
      "callout",
    ]);
    for (const callout of block.children) {
      expect(callout.children.map((child: any) => child.content)).toEqual([[]]);
    }
    expect(() => editor.prosemirrorState.doc.check()).not.toThrow();
  });

  it("Puts carried content before existing children", () => {
    const editor = getLayoutEditor();
    editor.transact((tr) =>
      updateBlock(tr, "paragraph-with-text-and-children", { type: "callout" }),
    );

    // The paragraph holding the carried text takes the place the text used to
    // occupy, i.e. above the children that were already nested under it.
    const block = editor.document[2] as any;
    expect(block.type).toBe("callout");
    expect(block.children.map((child: any) => child.content[0].text)).toEqual([
      "Parent text",
      "Existing child",
    ]);
    expect(block.children[1].id).toBe("existing-child");
    expect(() => editor.prosemirrorState.doc.check()).not.toThrow();
  });

  it("Drops table content when becoming a layout block", () => {
    const editor = getLayoutEditor();
    // Table content isn't an inline array, so there is no sensible paragraph to
    // wrap it in. It's dropped, and the layout block seeds as if the block had
    // been empty.
    expect(() =>
      editor.transact((tr) => updateBlock(tr, "table-0", { type: "callout" })),
    ).not.toThrow();

    const block = editor.document[3] as any;
    expect(block.type).toBe("callout");
    expect(block.content).toBeUndefined();
    expect(block.children).toHaveLength(1);
    expect(block.children[0].type).toBe("paragraph");
    expect(block.children[0].content).toEqual([]);
    expect(() => editor.prosemirrorState.doc.check()).not.toThrow();
  });

  it.each(["paragraph-with-text", "callout-0"])(
    "Rejects conversion of %s rather than dropping incompatible children",
    (id) => {
      const editor = getLayoutEditor();
      const before = editor.prosemirrorState.doc;
      expect(() =>
        editor.transact((tr) => updateBlock(tr, id, { type: "grid" })),
      ).toThrow();
      expect(editor.prosemirrorState.doc.eq(before)).toBe(true);
    },
  );

  it("Allows explicit replacement children when converting to a restricted layout block", () => {
    const editor = getLayoutEditor();
    editor.transact((tr) =>
      updateBlock(tr, "callout-0", {
        type: "grid",
        children: [
          {
            type: "gridCell",
            children: [{ type: "paragraph", content: "Replacement" }],
          },
          { type: "gridCell", children: [{ type: "paragraph" }] },
        ],
      }),
    );
    expect(editor.document[4].type).toBe("grid");
    expect(() => editor.prosemirrorState.doc.check()).not.toThrow();
  });

  it("Keeps a layout block's children when changing between layout block types", () => {
    const editor = getLayoutEditor();
    editor.transact((tr) => updateBlock(tr, "callout-0", { type: "box" }));

    // Neither layout block holds content of its own, so the children move across
    // untouched rather than being re-seeded.
    const block = editor.document[4] as any;
    expect(block.type).toBe("box");
    expect(block.children.map((child: any) => child.id)).toEqual([
      "callout-child",
    ]);
    expect(() => editor.prosemirrorState.doc.check()).not.toThrow();
  });

  it("Keeps a layout block's children alongside the content it gains", () => {
    const editor = getLayoutEditor();
    editor.transact((tr) =>
      updateBlock(tr, "callout-0", {
        type: "heading",
        content: "Now a heading",
      }),
    );

    // The layout block had nowhere to put inline content; the heading does, so
    // the given content lands there and the children stay nested under it.
    const block = editor.document[4] as any;
    expect(block.type).toBe("heading");
    expect(block.content).toEqual([
      { type: "text", text: "Now a heading", styles: {} },
    ]);
    expect(block.children.map((child: any) => child.id)).toEqual([
      "callout-child",
    ]);
    expect(() => editor.prosemirrorState.doc.check()).not.toThrow();
  });

  it("Updates a layout block's props without rebuilding it", () => {
    const editor = getLayoutEditor();
    editor.transact((tr) =>
      updateBlock(tr, "callout-0", { props: { flavor: "warning" } }),
    );

    // No shape change, so this is an in-place attribute update: the layout block
    // keeps its ID (unlike the type changes above) and its children.
    const block = editor.document[4] as any;
    expect(block.id).toBe("callout-0");
    expect(block.props.flavor).toBe("warning");
    expect(block.children.map((child: any) => child.id)).toEqual([
      "callout-child",
    ]);
    expect(() => editor.prosemirrorState.doc.check()).not.toThrow();
  });

  it("Keeps a layout block's children and invents no content when becoming a block", () => {
    const editor = getLayoutEditor();
    editor.transact((tr) =>
      updateBlock(tr, "callout-0", { type: "paragraph" }),
    );

    const block = editor.document[4] as any;
    expect(block.type).toBe("paragraph");
    expect(block.id).toBe("callout-0");
    expect(block.content).toEqual([]);
    expect(block.children).toHaveLength(1);
    expect(block.children[0].id).toBe("callout-child");
    expect(() => editor.prosemirrorState.doc.check()).not.toThrow();
  });
});
