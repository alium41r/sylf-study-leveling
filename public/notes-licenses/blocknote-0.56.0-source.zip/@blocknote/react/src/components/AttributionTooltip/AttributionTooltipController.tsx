import type {
  AttributionExtension,
  AttributionTooltipState,
} from "@blocknote/core/y";
import { flip, offset, shift, inline } from "@floating-ui/react";
import { FC, useMemo } from "react";

import { useExtensionState } from "../../hooks/useExtension.js";
import { PortalElementOverride } from "../../editor/PortalElementOverride.js";
import { FloatingUIOptions } from "../Popovers/FloatingUIOptions.js";
import { GenericPopover } from "../Popovers/GenericPopover.js";
import { AttributionTooltip } from "./AttributionTooltip.js";
import { AttributionTooltipProps } from "./AttributionTooltipProps.js";
import { FormatChangeLabel } from "./formatChangeLabel.js";

function getReferenceElement(wrapper: Element): Element {
  const content = wrapper.firstElementChild ?? wrapper;
  const rect = content.getBoundingClientRect();
  return rect.width || rect.height
    ? content
    : (content.firstElementChild ?? content);
}

function getTooltipProps(
  state: AttributionTooltipState,
  formatChangeLabel: FormatChangeLabel | undefined,
): AttributionTooltipProps {
  const { anchor: _anchor, reference: _reference, ...tooltipState } = state;
  return { ...tooltipState, formatChangeLabel };
}

/**
 * Renders the attribution tooltip for suggestion marks. The core
 * `AttributionExtension` owns the mark logic (which mark is hovered, nested-mark
 * resolution, username resolution, optional styling class) and emits the raw
 * change context; this controller subscribes to its store and positions the
 * tooltip with floating-ui. Composing the change context into localized text is
 * left to the tooltip component itself.
 */
export const AttributionTooltipController = (props: {
  attributionTooltip?: FC<AttributionTooltipProps>;
  /**
   * Turns a modification mark's changed formats into its tooltip label (e.g.
   * `"Bold, Italic"`). Forwarded to the tooltip component, which falls back to
   * localizing each format via the formatting toolbar strings.
   */
  formatChangeLabel?: FormatChangeLabel;
  floatingUIOptions?: FloatingUIOptions;
  /**
   * Override the DOM node this floating element portals into. Falls back to
   * the ambient portal target when omitted.
   */
  portalElement?: HTMLElement;
}) => {
  const state = useExtensionState<typeof AttributionExtension>("attribution", {
    selector: (state) => state,
  });

  // Attribution wrappers use `display: contents` and have no box, so anchor
  // the popover to their painted descendant instead. Using a regular element
  // reference lets GenericPopover own geometry, lifecycle caching, and the
  // per-line client rects consumed by `inline()`.
  const reference = useMemo(
    () =>
      state
        ? { element: state.reference ?? getReferenceElement(state.anchor) }
        : undefined,
    [state],
  );

  const floatingUIOptions = useMemo<FloatingUIOptions>(
    () => ({
      ...props.floatingUIOptions,
      useFloatingOptions: {
        open: !!state,
        placement: "top-start",
        middleware: [inline(), offset(4), flip(), shift({ padding: 4 })],
        ...props.floatingUIOptions?.useFloatingOptions,
      },
      // Non-interactive tooltip: no focus trapping and no pointer capture (so it
      // never interferes with the hover that drives it).
      focusManagerProps: {
        disabled: true,
        ...props.floatingUIOptions?.focusManagerProps,
      },
      elementProps: {
        style: {
          zIndex: 10000,
          pointerEvents: "none",
        },
        ...props.floatingUIOptions?.elementProps,
      },
    }),
    [props.floatingUIOptions, state],
  );

  const Component = props.attributionTooltip || AttributionTooltip;

  // The raw change context is handed to the component as-is; composing it into
  // display text (and localizing it) is the component's job.
  const tooltipProps: AttributionTooltipProps | undefined = state
    ? getTooltipProps(state, props.formatChangeLabel)
    : undefined;

  return (
    <PortalElementOverride target={props.portalElement}>
      <GenericPopover reference={reference} {...floatingUIOptions}>
        {tooltipProps && <Component {...tooltipProps} />}
      </GenericPopover>
    </PortalElementOverride>
  );
};
