export * from "./api/blockManipulation/commands/insertBlocks/insertBlocks.js";
export * from "./api/blockManipulation/commands/replaceBlocks/replaceBlocks.js";
export { isLayoutNode } from "./schema/blocks/children.js";
export { getBlockElementForNode } from "./extensions/blockDOM.js";
export { applyLayoutBlockAttributes } from "./schema/blocks/layoutBlockAttributes.js";
export {
  fixLayoutBlock,
  isEmptyLayoutChild,
} from "./api/blockManipulation/layoutBlocks/fixLayoutBlock.js";
export * from "./api/blockManipulation/commands/updateBlock/updateBlock.js";
export * from "./api/exporters/html/externalHTMLExporter.js";
export * from "./api/exporters/html/internalHTMLSerializer.js";
export * from "./api/getBlockInfoFromPos.js";
export * from "./api/getBlocksChangedByTransaction.js";
export * from "./pm-nodes/suggestionMarks.js";
export * from "./api/nodeUtil.js";
export * from "./api/pmUtil.js";
export * from "./blocks/index.js";
export * from "./editor/BlockNoteEditor.js";
export type { EditorFocusOptions } from "./editor/managers/EventManager.js";
export * from "./editor/BlockNoteExtension.js";
export * from "./editor/defaultColors.js";
export * from "./editor/selectionTypes.js";
export * from "./exporter/index.js";
export * from "./extensions-shared/UiElementPosition.js";
export { getDefaultEmojiPickerItems } from "./extensions/SuggestionMenu/getDefaultEmojiPickerItems.js";
export {
  filterSuggestionItems,
  getDefaultSlashMenuItems,
  insertOrUpdateBlockForSlashMenu,
} from "./extensions/SuggestionMenu/getDefaultSlashMenuItems.js";
export * from "./i18n/dictionary.js";
export * from "./schema/index.js";
export * from "./user/index.js";
export * from "./util/browser.js";
export * from "./util/combineByGroup.js";
export * from "./util/expandToWords.js";
export * from "./util/Store.js";
export * from "./util/string.js";
export * from "./util/table.js";
export * from "./util/typescript.js";

export type {
  CodeBlockOptions,
  CodeBlockPreview,
} from "./blocks/Code/CodeBlockOptions.js";
export { assertEmpty, UnreachableCaseError } from "./util/typescript.js";

export * from "./util/EventEmitter.js";
// for testing from react (TODO: move)
// Unit testing
export { selectedFragmentToHTML } from "./api/clipboard/toClipboard/copyExtension.js";

// Node conversions
export * from "./api/nodeConversions/blockToNode.js";
export * from "./api/nodeConversions/fragmentToBlocks.js";
export * from "./api/nodeConversions/nodeToBlock.js";

// for server-util (TODO: maybe move):
export * from "./api/exporters/markdown/markdownExporter.js";
export * from "./api/parsers/html/parseHTML.js";
export * from "./api/parsers/markdown/parseMarkdown.js";

// TODO: for ai, remove?
export * from "./api/blockManipulation/getBlock/getBlock.js";
export * from "./api/positionMapping.js";
