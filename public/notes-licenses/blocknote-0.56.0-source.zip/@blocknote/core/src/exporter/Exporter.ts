import { BlockNoteSchema } from "../blocks/BlockNoteSchema.js";
import { COLORS_DEFAULT } from "../editor/defaultColors.js";
import type { Dictionary } from "../i18n/dictionary.js";
import { en } from "../i18n/locales/index.js";
import {
  BlockNoDefaults,
  BlockSchema,
  InlineContent,
  InlineContentSchema,
  StyleSchema,
  StyledText,
  Styles,
} from "../schema/index.js";

import type {
  BlockMapping,
  InlineContentMapping,
  StyleMapping,
} from "./mapping.js";

export type ExporterOptions = {
  /**
   * A function that can be used to resolve files, images, etc.
   * Exporters might need the binary contents of files like images,
   * which might not always be available from the same origin as the main page.
   * You can use this option to proxy requests through a server you control
   * to avoid cross-origin (CORS) issues.
   *
   * @default uses a BlockNote hosted proxy (https://corsproxy.api.blocknotejs.org/)
   * @param url - The URL of the file to resolve
   * @returns A Promise that resolves to a string (the URL to use instead of the original)
   * or a Blob (you can return the Blob directly if you have already fetched it)
   */
  resolveFileUrl?: (url: string) => Promise<string | Blob>;
  /**
   * Colors to use for background of blocks, font colors, and highlight colors
   */
  colors: typeof COLORS_DEFAULT;
  /**
   * The strings an exporter renders into the produced document (file link
   * texts, error placeholders). Accepts a locale from
   * `@blocknote/core/locales` or an editor dictionary; block packages that
   * ship their own exporter strings (e.g. math, diagram) read their sections
   * from this same object, exactly as they do from an editor dictionary.
   *
   * @default the English strings
   */
  dictionary?: { exporter: Dictionary["exporter"] } & {
    // Block packages read their own sections (e.g. `math`, `diagram`) from
    // the same object; their types live with those packages.
    [blockDictionary: string]: unknown;
  };
};
export abstract class Exporter<
  B extends BlockSchema,
  I extends InlineContentSchema,
  S extends StyleSchema,
  RB,
  RI,
  RS,
  TS,
> {
  public constructor(
    protected readonly schema: BlockNoteSchema<B, I, S>,
    protected readonly mappings: {
      blockMapping: BlockMapping<B, I, S, RB, RI>;
      inlineContentMapping: InlineContentMapping<I, S, RI, TS>;
      styleMapping: StyleMapping<S, RS>;
    },
    public readonly options: ExporterOptions,
  ) {}

  /**
   * Whether the block's mapping places its children itself (a `{ withChildren }`
   * mapping). Otherwise the exporter places them after the block.
   */
  public placesChildren(block: { type: string }): boolean {
    const mapping = this.mappings.blockMapping[block.type];
    return typeof mapping === "object" && mapping !== null;
  }

  /**
   * The strings this exporter renders into the produced document - the
   * `exporter` section of the configured dictionary (the `dictionary`
   * option of {@link ExporterOptions}), or the English defaults.
   */
  public get dictionary(): Dictionary["exporter"] {
    return this.options.dictionary?.exporter ?? en.exporter;
  }

  public async resolveFile(url: string) {
    if (!this.options?.resolveFileUrl) {
      return this.fetchBlob(url);
    }
    const ret = await this.options.resolveFileUrl(url);
    if (ret instanceof Blob) {
      return ret;
    }
    return this.fetchBlob(ret);
  }

  /**
   * Fetch a URL as a Blob, throwing a clear error on a non-OK response. Without
   * this an error page (404 / rate-limit / proxy failure) would be returned as
   * the file's bytes and silently embedded as a corrupt image. An unreachable
   * file is an environment failure, not expected input, so it fails the export
   * loudly (see the error-handling conventions in AGENTS.md) rather than
   * degrading the document silently.
   */
  private async fetchBlob(url: string): Promise<Blob> {
    const res = await fetch(url);
    if (!res.ok) {
      throw new Error(
        `Failed to fetch file "${url}": ${res.status} ${res.statusText}`,
      );
    }
    return res.blob();
  }

  public mapStyles(styles: Styles<S>) {
    const stylesArray = Object.entries(styles).map(([key, value]) => {
      const mapping = this.mappings.styleMapping[key];
      if (!mapping) {
        throw new Error(
          `Exporter is missing a style mapping for style "${key}". If this style comes from a separate package, spread that package's exporter mappings into your styleMapping.`,
        );
      }
      const mappedStyle = mapping(value, this);
      return mappedStyle;
    });
    return stylesArray;
  }

  public mapInlineContent(inlineContent: InlineContent<I, S>) {
    const mapping = this.mappings.inlineContentMapping[inlineContent.type];
    if (!mapping) {
      throw new Error(
        `Exporter is missing an inline content mapping for inline content type "${inlineContent.type}". If this inline content comes from a separate package, spread that package's exporter mappings into your inlineContentMapping.`,
      );
    }
    return mapping(inlineContent, this);
  }

  public transformInlineContent(inlineContentArray: InlineContent<I, S>[]) {
    return inlineContentArray.map((ic) => this.mapInlineContent(ic));
  }

  public abstract transformStyledText(styledText: StyledText<S>): TS;

  public async mapBlock(
    block: BlockNoDefaults<B, I, S>,
    nestingLevel: number,
    numberedListIndex: number,
    children?: Array<Awaited<RB>>,
  ) {
    const mapping = this.mappings.blockMapping[block.type];
    if (!mapping) {
      throw new Error(
        `Exporter is missing a block mapping for block type "${block.type}". If this block comes from a separate package, spread that package's exporter mappings into your blockMapping.`,
      );
    }
    if (typeof mapping === "function") {
      // A layout block's children belong inside it, which only a
      // `{ withChildren }` mapping can do. Fail early rather than export them
      // after it.
      // TODO: remove once the `BlockMapping` type requires `{ withChildren }`
      // for layout blocks (`createBlockSpec` doesn't keep `layoutOnly: true` in the
      // config type yet).
      const spec = this.schema.blockSpecs[block.type];
      if (spec !== undefined && spec.config.layoutOnly === true) {
        throw new Error(
          `The mapping for layout block type "${block.type}" must be a \`{ withChildren }\` mapping, which places the block's children.`,
        );
      }
      return mapping(block, this, nestingLevel, numberedListIndex);
    }
    return mapping.withChildren(
      block,
      this,
      nestingLevel,
      numberedListIndex,
      children ?? [],
    );
  }
}
