import { useCallback, useEffect, useState } from "react";
import { RiLink } from "react-icons/ri";

import {
  BlockNoteEditor,
  BlockSchema,
  formatKeyboardShortcut,
  isTableCellSelection,
  StyleSchema,
} from "@blocknote/core";
import {
  FormattingToolbarExtension,
  ShowSelectionExtension,
} from "@blocknote/core/extensions";

import { useComponentsContext } from "../../../editor/ComponentsContext.js";
import { usePortalElement } from "../../../editor/PortalElementOverride.js";
import { useBlockNoteEditor } from "../../../hooks/useBlockNoteEditor.js";
import { useEditorDOMElement } from "../../../hooks/useEditorDomElement.js";
import { useEditorState } from "../../../hooks/useEditorState.js";
import { useExtension } from "../../../hooks/useExtension.js";
import { useDictionary } from "../../../i18n/dictionary.js";
import { EditLinkMenuItems } from "../../LinkToolbar/EditLinkMenuItems.js";

function checkLinkInSchema(
  editor: BlockNoteEditor<BlockSchema, any, StyleSchema>,
): editor is BlockNoteEditor<
  BlockSchema,
  {
    link: {
      type: "link";
      propSchema: any;
      content: "styled";
    };
  },
  StyleSchema
> {
  return (
    "link" in editor.schema.inlineContentSchema &&
    editor.schema.inlineContentSchema["link"] === "link"
  );
}

export const CreateLinkButton = () => {
  const editor = useBlockNoteEditor<any, any, any>();
  const editorDOMElement = useEditorDOMElement();
  const Components = useComponentsContext()!;
  const dict = useDictionary();
  const portalElement = usePortalElement();

  const formattingToolbar = useExtension(FormattingToolbarExtension);
  // eslint-disable-next-line @typescript-eslint/unbound-method -- showSelection is a plain object method, not a class method
  const { showSelection } = useExtension(ShowSelectionExtension);

  const [showPopover, setShowPopover] = useState(false);
  useEffect(() => {
    showSelection(showPopover, "createLinkButton");
    return () => showSelection(false, "createLinkButton");
  }, [showPopover, showSelection]);

  // Return focus to editor on close.
  const setPopoverOpen = useCallback(
    (open: boolean) => {
      if (!open) {
        editor.focus();
      }
      setShowPopover(open);
    },
    [editor],
  );

  const state = useEditorState({
    editor,
    selector: ({ editor }) => {
      // Do not show if:
      if (
        // The editor is read-only.
        !editor.isEditable ||
        // The selection is empty, i.e. no content is selected.
        editor.prosemirrorState.selection.empty ||
        // Links are not in the schema.
        !checkLinkInSchema(editor) ||
        // Table cells are selected.
        isTableCellSelection(editor.prosemirrorState.selection) ||
        // None of the selected blocks have inline content
        !(
          editor.getSelection()?.blocks || [
            editor.getTextCursorPosition().block,
          ]
        ).find((block) => block.content !== undefined)
      ) {
        return undefined;
      }

      return {
        url: editor.getSelectedLinkUrl(),
        text: editor.getSelectedText(),
        range: {
          from: editor.prosemirrorState.selection.from,
          to: editor.prosemirrorState.selection.to,
        },
      };
    },
  });
  useEffect(() => {
    // Closing in response to editor state changes keeps an invalid selection
    // from leaving the create-link popover open.
    // eslint-disable-next-line react/set-state-in-effect
    setShowPopover(false);
  }, [state]);

  // Makes Ctrl+K/Meta+K open link creation popover.
  useEffect(() => {
    const callback = (event: KeyboardEvent) => {
      // A read-only editor (e.g. while a version preview is open) has no link
      // creation to offer, so leave the shortcut to the browser.
      if (!editor.isEditable) {
        return;
      }
      if ((event.ctrlKey || event.metaKey) && event.key === "k") {
        setShowPopover(true);
        event.preventDefault();
      }
    };

    editorDOMElement?.addEventListener("keydown", callback);

    return () => {
      editorDOMElement?.removeEventListener("keydown", callback);
    };
  }, [editor, editorDOMElement]);

  if (state === undefined) {
    return null;
  }

  return (
    <Components.Generic.Popover.Root
      open={showPopover}
      onOpenChange={setPopoverOpen}
      // Portal the popover into the editor's themed portal target so it
      // inherits styling and escapes any scroll-container overflow clipping.
      portalElement={portalElement}
    >
      <Components.Generic.Popover.Trigger>
        {/* TODO: hide tooltip on click */}
        <Components.FormattingToolbar.Button
          className={"bn-button"}
          data-test="createLink"
          label={dict.formatting_toolbar.link.tooltip}
          mainTooltip={dict.formatting_toolbar.link.tooltip}
          secondaryTooltip={formatKeyboardShortcut(
            dict.formatting_toolbar.link.secondary_tooltip,
            dict.generic.ctrl_shortcut,
          )}
          icon={<RiLink />}
          onClick={() => setPopoverOpen(!showPopover)}
        />
      </Components.Generic.Popover.Trigger>
      <Components.Generic.Popover.Content
        className={"bn-popover-content bn-form-popover"}
        variant={"form-popover"}
      >
        <EditLinkMenuItems
          url={state.url || ""}
          text={state.text}
          range={state.range}
          showTextField={false}
          // (No explicit popover close here: any editor-state change — like
          // submitting the link — already closes it via the setShowPopover
          // effect above.)
          setToolbarOpen={(open) => formattingToolbar.store.setState(open)}
        />
      </Components.Generic.Popover.Content>
    </Components.Generic.Popover.Root>
  );
};
