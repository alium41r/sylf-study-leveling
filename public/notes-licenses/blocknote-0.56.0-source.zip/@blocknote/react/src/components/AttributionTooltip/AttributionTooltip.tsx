import { useMemo } from "react";

import { useComponentsContext } from "../../editor/ComponentsContext.js";
import { useDictionary } from "../../i18n/dictionary.js";
import { AttributionTooltipProps } from "./AttributionTooltipProps.js";
import { defaultFormatChangeLabel } from "./formatChangeLabel.js";

/**
 * The default attribution tooltip shown when hovering a suggestion mark. Renders
 * the author label (and, for modification marks, the localized formatting-change
 * label) via the themeable `AttributionTooltip` component slot.
 *
 * When `className` is set (from a `getAttributionMarkClassName` callback), it's
 * forwarded so the app's CSS controls the color and the per-user `color` is
 * dropped; otherwise the author color is applied inline.
 */
export const AttributionTooltip = (props: AttributionTooltipProps) => {
  const Components = useComponentsContext()!;
  const dictionary = useDictionary();

  // Compose the fully-localized text from the raw change context — e.g.
  // `"Inserted by: Alice"` or `"Formatting change (Bold, Italic) by: Alice"`.
  // A version diff has no authors and can't tell which intermediate version
  // made a change, so it only names the kind of change (e.g. `"Inserted"`).
  // The outer sentence comes from the `suggestion_changes` dictionary
  // (translated per locale) and the inner format list from the configurable
  // `formatChangeLabel`.
  const text = useMemo(() => {
    const changes = dictionary.suggestion_changes;
    const formatChangeLabel =
      props.formatChangeLabel ?? defaultFormatChangeLabel;
    const users = props.users.join(", ");

    if (props.modificationType === "insert") {
      return users ? changes.inserted_by(users) : changes.inserted;
    }
    if (props.modificationType === "delete") {
      return users ? changes.deleted_by(users) : changes.deleted;
    }
    if (props.modificationType === "change") {
      return users ? changes.changed_by(users) : changes.changed;
    }

    if (props.modificationType === "attrs") {
      return users
        ? `${changes.formatting_change}: ${users}`
        : changes.formatting_change;
    }

    const formatLabel = props.format
      ? formatChangeLabel({ format: props.format, dictionary })
      : "";
    // When the label falls back to the generic string (unknown/empty formats),
    // rendering it inside `formatting_change_by` would duplicate it as
    // "Formatting change (Formatting Change) by: ...", so list it once instead.
    if (!formatLabel || formatLabel === changes.formatting_change) {
      return users
        ? `${changes.formatting_change}: ${users}`
        : changes.formatting_change;
    }
    return users
      ? changes.formatting_change_by(formatLabel, users)
      : `${changes.formatting_change} (${formatLabel})`;
  }, [dictionary, props]);
  return (
    <Components.AttributionTooltip.Root
      className={"bn-suggestion-tooltip"}
      markClassName={props.className}
      backgroundColor={props.className ? undefined : props.color}
    >
      {text}
    </Components.AttributionTooltip.Root>
  );
};
