import { DOMSerializer, Fragment, Node } from "prosemirror-model";

import { PartialBlock } from "../../../../blocks/defaultBlocks.js";
import type { BlockNoteEditor } from "../../../../editor/BlockNoteEditor.js";
import {
  BlockImplementation,
  BlockSchema,
  InlineContentSchema,
  StyleSchema,
} from "../../../../schema/index.js";
import { isLayoutNode } from "../../../../schema/blocks/children.js";
import {
  FRAME_SLOT_ATTRIBUTE,
  renderFrameDOM,
} from "../../../../schema/blocks/frame.js";
import { isDocumentFragment } from "../../../../schema/blocks/internal.js";
import { UnreachableCaseError } from "../../../../util/typescript.js";
import {
  inlineContentToNodes,
  tableContentToNodes,
} from "../../../nodeConversions/blockToNode.js";
import { nodeToCustomInlineContent } from "../../../nodeConversions/nodeToBlock.js";

/**
 * Placeholder character inserted into empty inline-content blocks when
 * exporting to external HTML. An empty block serializes to an element with no
 * children (e.g. `<p></p>`), which is dropped when the HTML is parsed back into
 * blocks. Filling it with this character keeps the block alive through the
 * round trip, and the parser strips the character again so the block ends up
 * empty (see `HTMLToBlocks`).
 *
 * The Unicode object replacement character (U+FFFC) is used because it's a
 * reserved placeholder that users don't type, so it can be safely removed on
 * import without discarding legitimate content (unlike a non-breaking space).
 */
export const EMPTY_BLOCK_PLACEHOLDER = "￼";

function addAttributesAndRemoveClasses(element: HTMLElement) {
  // Removes all BlockNote specific class names.
  const className =
    Array.from(element.classList).filter(
      (className) => !className.startsWith("bn-"),
    ) || [];

  if (className.length > 0) {
    element.className = className.join(" ");
  } else {
    element.removeAttribute("class");
  }
}

export function serializeInlineContentExternalHTML<
  BSchema extends BlockSchema,
  I extends InlineContentSchema,
  S extends StyleSchema,
>(
  editor: BlockNoteEditor<any, I, S>,
  blockContent: PartialBlock<BSchema, I, S>["content"],
  serializer: DOMSerializer,
  options?: { document?: Document; blockType?: string },
) {
  let nodes: Node[];

  // TODO: reuse function from nodeconversions?
  if (!blockContent) {
    throw new Error("blockContent is required");
  } else if (typeof blockContent === "string") {
    nodes = inlineContentToNodes(
      [blockContent],
      editor.pmSchema,
      options?.blockType,
    );
  } else if (Array.isArray(blockContent)) {
    nodes = inlineContentToNodes(
      blockContent,
      editor.pmSchema,
      options?.blockType,
    );
  } else if (blockContent.type === "tableContent") {
    nodes = tableContentToNodes(blockContent, editor.pmSchema);
  } else {
    throw new UnreachableCaseError(blockContent.type);
  }

  // Check if any of the nodes are custom inline content with toExternalHTML
  const doc = options?.document ?? document;
  const fragment = doc.createDocumentFragment();

  for (const node of nodes) {
    // Check if this is a custom inline content node with toExternalHTML
    if (
      node.type.name !== "text" &&
      editor.schema.inlineContentSchema[node.type.name]
    ) {
      const inlineContentImplementation =
        editor.schema.inlineContentSpecs[node.type.name].implementation;

      if (inlineContentImplementation) {
        // Convert the node to inline content format
        const inlineContent = nodeToCustomInlineContent(
          node,
          editor.schema.inlineContentSchema,
          editor.schema.styleSchema,
        );

        // Use the custom toExternalHTML method or fallback to `render`
        const output = inlineContentImplementation.toExternalHTML
          ? inlineContentImplementation.toExternalHTML(
              inlineContent as any,
              editor as any,
            )
          : inlineContentImplementation.render.call(
              {
                renderType: "dom",
                props: undefined,
              },
              inlineContent as any,
              () => {
                // No-op
              },
              editor as any,
            );

        if (output) {
          fragment.appendChild(output.dom);

          // If contentDOM exists, render the inline content into it
          if (output.contentDOM) {
            const contentFragment = serializer.serializeFragment(
              node.content,
              options,
            );
            output.contentDOM.dataset.editable = "";
            output.contentDOM.appendChild(contentFragment);
          }
          continue;
        }
      }
    } else if (node.type.name === "text") {
      // We serialize text nodes manually as we need to serialize the styles/
      // marks using `styleSpec.implementation.render`. When left up to
      // ProseMirror, it'll use `toDOM` which is incorrect.
      let dom: globalThis.Node | Text = document.createTextNode(
        node.textContent,
      );
      // Reverse the order of marks to maintain the correct priority.
      for (const mark of node.marks.toReversed()) {
        if (mark.type.name in editor.schema.styleSpecs) {
          const newDom = (
            editor.schema.styleSpecs[mark.type.name].implementation
              .toExternalHTML ??
            editor.schema.styleSpecs[mark.type.name].implementation.render
          )(mark.attrs["stringValue"], editor);
          newDom.contentDOM!.appendChild(dom);
          dom = newDom.dom;
        } else {
          const domOutputSpec = mark.type.spec.toDOM!(mark, true);
          const newDom = DOMSerializer.renderSpec(document, domOutputSpec);
          newDom.contentDOM!.appendChild(dom);
          dom = newDom.dom;
        }
      }

      fragment.appendChild(dom);
    } else {
      // Fall back to default serialization for this node
      const nodeFragment = serializer.serializeFragment(
        Fragment.from([node]),
        options,
      );
      fragment.appendChild(nodeFragment);
    }
  }

  if (
    fragment.childNodes.length === 1 &&
    fragment.firstChild?.nodeType === 1 /* Node.ELEMENT_NODE */
  ) {
    addAttributesAndRemoveClasses(fragment.firstChild as HTMLElement);
  }

  return fragment;
}

/** A block's external HTML, before the serializer post-processes it. */
type BlockOutput = {
  dom: HTMLElement | DocumentFragment;
  contentDOM?: HTMLElement;
  childrenDOM?: HTMLElement;
};

/**
 * The block's output for external HTML, and the frame to put it into. The
 * block's own `toExternalHTML` replaces the default export, frame included.
 * By default, a layout block is its frame, with the children in the slot, and
 * any other block is `render`'s output, which the caller puts into the
 * block's frame (if it draws one).
 */
function renderBlockOutput(
  blockImplementation: BlockImplementation,
  block: any,
  editor: BlockNoteEditor<any, any, any>,
  isLayoutBlock: boolean,
  nestingLevel: number,
): { output: BlockOutput; frame?: { dom: HTMLElement; slot: HTMLElement } } {
  const external = blockImplementation.toExternalHTML?.call({}, block, editor, {
    nestingLevel,
  });
  if (external) {
    return { output: external };
  }

  const frame = renderFrameDOM(editor, block);
  if (isLayoutBlock) {
    if (!frame) {
      throw new Error(
        `Layout block "${block.type}" drew no frame. This is a bug in BlockNote.`,
      );
    }
    return { output: { dom: frame.dom, childrenDOM: frame.slot } };
  }

  if (!blockImplementation.render) {
    throw new Error(
      `Block "${block.type}" has no \`render\`. This is a bug in BlockNote.`,
    );
  }
  return { output: blockImplementation.render.call({}, block, editor), frame };
}

/**
 * TODO: there's still quite some logic that handles getting and filtering properties,
 * we should make sure the `toExternalHTML` methods of default blocks actually handle this,
 * instead of the serializer.
 */
function serializeBlock<
  BSchema extends BlockSchema,
  I extends InlineContentSchema,
  S extends StyleSchema,
>(
  fragment: DocumentFragment,
  editor: BlockNoteEditor<BSchema, I, S>,
  block: PartialBlock<BSchema, I, S>,
  serializer: DOMSerializer,
  orderedListItemBlockTypes: Set<string>,
  unorderedListItemBlockTypes: Set<string>,
  nestingLevel: number,
  options?: { document?: Document },
) {
  const doc = options?.document ?? document;
  const BC_NODE = editor.pmSchema.nodes["blockContainer"];

  // set default props in case we were passed a partial block
  const props = block.props || {};
  for (const [name, spec] of Object.entries(
    editor.schema.blockSchema[block.type as any].propSchema,
  )) {
    if (!(name in props) && spec.default !== undefined) {
      (props as any)[name] = spec.default;
    }
  }

  const bc = BC_NODE.spec?.toDOM?.(
    BC_NODE.create({
      id: block.id,
      ...props,
    }),
  ) as {
    dom: HTMLElement;
    contentDOM?: HTMLElement;
  };

  // the container node is just used as a workaround to get some block-level attributes.
  // we should change toExternalHTML so that this is not necessary
  const attrs = Array.from(bc.dom.attributes);

  const blockImplementation = editor.blockImplementations[block.type as any]
    .implementation as BlockImplementation;
  const blockWithDefaults = { ...block, props, children: block.children ?? [] };
  const isLayoutBlock = isLayoutNode(editor.pmSchema.nodes[block.type as any]);
  const { output: ret, frame } = renderBlockOutput(
    blockImplementation,
    blockWithDefaults,
    editor,
    isLayoutBlock,
    nestingLevel,
  );

  const elementFragment = doc.createDocumentFragment();

  let rootElement: HTMLElement | undefined;
  if (!isDocumentFragment(ret.dom)) {
    rootElement = ret.dom;
  }

  if (rootElement?.classList.contains("bn-block-content")) {
    const blockContentDataAttributes = [
      ...attrs,
      ...Array.from(rootElement.attributes),
    ].filter(
      (attr) =>
        attr.name.startsWith("data") &&
        attr.name !== "data-content-type" &&
        attr.name !== "data-file-block" &&
        attr.name !== "data-node-view-wrapper" &&
        attr.name !== "data-node-type" &&
        attr.name !== "data-id" &&
        attr.name !== "data-editable",
    );

    for (const attr of blockContentDataAttributes) {
      (rootElement.firstChild! as HTMLElement).setAttribute(
        attr.name,
        attr.value,
      );
    }

    addAttributesAndRemoveClasses(rootElement.firstChild! as HTMLElement);
    if (nestingLevel > 0) {
      (rootElement.firstChild! as HTMLElement).setAttribute(
        "data-nesting-level",
        nestingLevel.toString(),
      );
    }
    elementFragment.append(...Array.from(rootElement.childNodes));
  } else {
    elementFragment.append(ret.dom);
    if (isLayoutBlock) {
      // Like a regular block's type marker (`data-content-type`), a
      // layout block's markers stay out of external HTML: it parses back only
      // through the block's `parse`, like any other block. Its props stay as
      // `data-*` attributes. This mirrors the unwrapping of a regular block's
      // `.bn-block-content` above: the spec's hooks produce the editor's
      // structure with its markers, and this serializer strips them.
      // TODO: consider not adding the markers in the first place (only the
      // node view and the internal serializer need them), instead of adding
      // and then stripping them. If so, change it for regular blocks too
      // (`wrapInBlockStructure`), so both kinds of block keep one rule.
      rootElement?.removeAttribute("data-node-type");
      rootElement?.removeAttribute("data-id");
      ret.childrenDOM?.removeAttribute(FRAME_SLOT_ATTRIBUTE);
    }
    if (nestingLevel > 0) {
      rootElement?.setAttribute("data-nesting-level", nestingLevel.toString());
    }
  }

  if (ret.contentDOM) {
    if (block.content) {
      const ic = serializeInlineContentExternalHTML(
        editor,
        block.content as any, // TODO
        serializer,
        { ...options, blockType: block.type },
      );

      ret.contentDOM.appendChild(ic);
    }

    // Blocks with empty inline content (e.g. an empty paragraph) serialize to
    // an element with no children (e.g. `<p></p>`), which is ignored when the
    // HTML is parsed back into blocks. To make these blocks survive such a
    // round trip, we fill their content with a placeholder character that the
    // parser strips out again (see `EMPTY_BLOCK_PLACEHOLDER`).
    //
    // Only applies to blocks that hold inline content: containers (columns,
    // tables) fill their `contentDOM` with child blocks later on, and code
    // blocks would turn the placeholder into literal content.
    const blockNodeType = editor.pmSchema.nodes[block.type as any];
    const needsPlaceholder =
      !!blockNodeType?.inlineContent && !blockNodeType.spec.code;
    if (needsPlaceholder && ret.contentDOM.childNodes.length === 0) {
      ret.contentDOM.appendChild(doc.createTextNode(EMPTY_BLOCK_PLACEHOLDER));
    }
  }

  // Where the block's children go: where the block placed them, else in the
  // slot of the frame around its content.
  let childrenDOM = ret.childrenDOM;
  if (frame) {
    frame.slot.append(elementFragment);
    elementFragment.append(frame.dom);
    childrenDOM = frame.slot;
  }

  let listType = undefined;
  if (orderedListItemBlockTypes.has(block.type!)) {
    listType = "OL";
  } else if (unorderedListItemBlockTypes.has(block.type!)) {
    listType = "UL";
  }

  if (listType) {
    if (fragment.lastChild?.nodeName !== listType) {
      const list = doc.createElement(listType);

      if (
        listType === "OL" &&
        "start" in props &&
        props.start &&
        props?.start !== 1
      ) {
        // eslint-disable-next-line @typescript-eslint/no-base-to-string
        list.setAttribute("start", String(props.start));
      }
      fragment.append(list);
    }
    fragment.lastChild!.appendChild(elementFragment);
  } else {
    fragment.append(elementFragment);
  }

  if (block.children && block.children.length > 0) {
    const childFragment = doc.createDocumentFragment();
    serializeBlocksToFragment(
      childFragment,
      editor,
      block.children,
      serializer,
      orderedListItemBlockTypes,
      unorderedListItemBlockTypes,
      nestingLevel + 1,
      options,
    );
    if (
      fragment.lastChild?.nodeName === "UL" ||
      fragment.lastChild?.nodeName === "OL"
    ) {
      // add nested lists to the last list item
      while (
        childFragment.firstChild?.nodeName === "UL" ||
        childFragment.firstChild?.nodeName === "OL"
      ) {
        fragment.lastChild!.lastChild!.appendChild(childFragment.firstChild!);
      }
    }

    if (childrenDOM) {
      // block specifies where children should go (e.g. toggle blocks
      // place children inside <details>, or a frame's slot)
      childrenDOM.append(childFragment);
    } else if (
      editor.pmSchema.nodes[block.type as any].isInGroup("blockContent") ||
      !ret.contentDOM
    ) {
      // default "blockContainer" style blocks are flattened (no "nested block" support) for externalHTML, so append the child fragment to the outer fragment.
      // So does a layout block whose own export places its children nowhere.
      fragment.append(childFragment);
    } else {
      // for columns / column lists, do use nesting
      ret.contentDOM.append(childFragment);
    }
  }
}

const serializeBlocksToFragment = <
  BSchema extends BlockSchema,
  I extends InlineContentSchema,
  S extends StyleSchema,
>(
  fragment: DocumentFragment,
  editor: BlockNoteEditor<BSchema, I, S>,
  blocks: PartialBlock<BSchema, I, S>[],
  serializer: DOMSerializer,
  orderedListItemBlockTypes: Set<string>,
  unorderedListItemBlockTypes: Set<string>,
  nestingLevel = 0,
  options?: { document?: Document },
) => {
  for (const block of blocks) {
    serializeBlock(
      fragment,
      editor,
      block,
      serializer,
      orderedListItemBlockTypes,
      unorderedListItemBlockTypes,
      nestingLevel,
      options,
    );
  }
};

export const serializeBlocksExternalHTML = <
  BSchema extends BlockSchema,
  I extends InlineContentSchema,
  S extends StyleSchema,
>(
  editor: BlockNoteEditor<BSchema, I, S>,
  blocks: PartialBlock<BSchema, I, S>[],
  serializer: DOMSerializer,
  orderedListItemBlockTypes: Set<string>,
  unorderedListItemBlockTypes: Set<string>,
  options?: { document?: Document },
) => {
  const doc = options?.document ?? document;
  const fragment = doc.createDocumentFragment();

  serializeBlocksToFragment(
    fragment,
    editor,
    blocks,
    serializer,
    orderedListItemBlockTypes,
    unorderedListItemBlockTypes,
    0,
    options,
  );
  return fragment;
};
